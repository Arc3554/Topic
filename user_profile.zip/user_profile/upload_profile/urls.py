from django.urls import path
from . import views

urlpatterns = [
    #path('add/', views.add),
    #path('detail/', views.detail),
    path('make_poi/', views.Poi),
    path('make_aoi/', views.Map),
    path('make_loi/', views.Loi),
    path('make_soi/', views.Soi),
    path('demo/', views.Demo),
    path('login/', views.login),
    path('logout/', views.logout),
    path('sign_up/',views.sign_up),
    path('services/',views.services),
    path('index/',views.index),
     path('info/',views.info),
]