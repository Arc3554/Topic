from django.contrib import admin
from .models import SOI,AOI,LOI,MAP,diffMAP,Media,POI,POI_content,Beacon

class temp1(admin.ModelAdmin):
    list_display=('id', 'name',"intro","MAP_ID","contributor")

class temp2(admin.ModelAdmin):
    list_display=('id', 'name',"MAP_ID","SOI_ID","AOI_group","X","Y","floor","contributor")

class temp3(admin.ModelAdmin):
    list_display=('id', 'name','MAP_ID','SOI_ID',"LOI_group",'X','Y',"contributor")

class temp4(admin.ModelAdmin):
    list_display=('id', 'map_title','map_description','floor','TYPE','to_id','scale','Beacon_num')

class temp5(admin.ModelAdmin):
    list_display=('id', 'name','scale','MAP_ID')

class temp6(admin.ModelAdmin):
    list_display=('id', 'name','TYPE','to_id','url')

class temp7(admin.ModelAdmin):
    list_display=('id', 'poi_title','subject','media_type','contributor')

class temp8(admin.ModelAdmin):
    list_display=('id','X','Y','TYPE','to_id', 'POI_ID', 'order')
    
class temp9(admin.ModelAdmin):
    list_display=('id', 'name','MAP_ID','Beacon_X','Beacon_Y', 'rssi', 'Major','Minor')

admin.site.register(SOI,temp1)
admin.site.register(AOI,temp2)
admin.site.register(LOI,temp3)
admin.site.register(MAP,temp4)
admin.site.register(diffMAP,temp5)
admin.site.register(Media,temp6)
admin.site.register(POI,temp7)
admin.site.register(POI_content,temp8)
admin.site.register(Beacon,temp9)