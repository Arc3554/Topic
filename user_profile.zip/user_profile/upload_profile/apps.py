from django.apps import AppConfig


class UploadProfileConfig(AppConfig):
    name = 'upload_profile'
