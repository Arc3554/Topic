$(document).ready(function () {
    $("#stitchImage").offset($("#baseImage").offset());
        $('.drag').dragscroll({
            onStart: function($this) {
                
            },
            onMove: function($this) {
                
            },
            onEnd: function($this) {
                
            }
        });
		$('#PoiDetail').modal({
        onHide: function(){
			$(this).find('video')[0].pause();
			$('#poi_video').addClass("hidden");
			
        }
    });
});
function myMap() {
    var mapCanvas = document.getElementById("googleMap");
    var myLatLng = new google.maps.LatLng(23.5, 121.120850)
    geocoder = new google.maps.Geocoder();
    markersArray = [];
    var mapOptions = {
        center: myLatLng,
        zoom: 8
    }
    map = new google.maps.Map(mapCanvas, mapOptions);
    google.maps.event.addListener(map, "click", function (event) {
    myLatLng = event.latLng;
    geocoder.geocode({ 'latLng': myLatLng }, function (results, status) {
        if (status === google.maps.GeocoderStatus.OK) {
            map.setCenter(results[0].geometry.location);
            map.setZoom(12);
        }
        // 經緯度資訊錯誤
        else {
            alert("Google 無法辨視此位置 ");
        }
    });
    
    });
}
function placeMarker(location,type,contentString,ids) {
	var temp = "null";
	var i;
	if(temp != type){
		deleteOverlays();
	}
	temp = type;
	for(i = 0;i< location.length;++i){
		var marker = new google.maps.Marker({
			position: location[i],
			map: map,
		});	
		marker.id = ids[i];
		markersArray.push(marker);
		google.maps.event.addListener(marker, 'click',(function(marker, i) {
			return function() {
			  getDetail(type,marker.id);
			}
		  })(marker, i));
		var infowindow = new google.maps.InfoWindow({
			content: contentString[i].name +"<br>"+contentString[i].description,
			position: location[i]
		});
	}
	
	map.setCenter(location[0]);
	
   
}
function placeInfo(location,content){
	for(i = 0;i< location.length;++i){
	var infowindow = new google.maps.InfoWindow({
		content: content[i],
		position: location[i]
		});
		infowindow.open(map,location[i]);
	}
		
}
function deleteOverlays() {
    if (markersArray) {
        for (i in markersArray) {
            markersArray[i].setMap(null);
        }
        markersArray.length = 0;
    }
}

//get the map of choose title
async function getDetail(type,id){
	document.getElementById("ListContent").innerHTML = " ";
	document.getElementById("icons").innerHTML = " ";
	document.getElementById("beacons").innerHTML = " ";
	document.getElementById("SearchMenu").innerHTML = " ";
	var mapImg = "";
	await $.ajax({
	  url: "/api/MAP/getMap/",
	  type: "get", //send it through get method
	  data: { 
		type: type,
		id: id
	  },
	  success: function(response) {
		mapImg = response[0].url;
		getBeacon(response[0].m_id);
		document.getElementById("mapImg").setAttribute("name",response[0].m_id);		
	  },
	  error: function(xhr) {
		//Do Something to handle error
	  }
	});
	$('#googleMap').addClass("hidden");
    $('#rep').removeClass("hidden");
	$('#SearchField').closest("DIV").addClass("hidden");
	document.getElementById("mapImg").src = "../../media/"+mapImg;
	if(type == "SOI"){
		var btn1 = document.createElement("BUTTON");  
		btn1.className = "ui button";
		btn1.innerHTML = "景點";
		btn1.addEventListener('click', function(){
			searchPOI(type,id);
		});
		btn1.setAttribute("id", "searchPOI");
		var btn2 = document.createElement("BUTTON");  
		btn2.className = "ui button";
		btn2.innerHTML = "景線";
		btn2.addEventListener('click', function(){
			searchLOI(type,id);
		});
		btn2.setAttribute("id", "searchLOI");
		var btn3 = document.createElement("BUTTON");  
		btn3.className = "ui button";
		btn3.innerHTML = "景區";
		btn3.addEventListener('click', function(){
			searchAOI(type,id);
		});
		btn3.setAttribute("id", "searchAOI");
		document.getElementById("SearchMenu").appendChild(btn1);
		document.getElementById("SearchMenu").appendChild(btn2); 
		document.getElementById("SearchMenu").appendChild(btn3);    
	}
	if(type == "LOI"){
		var btn1 = document.createElement("BUTTON");  
		btn1.className = "ui button";
		btn1.innerHTML = "景點";
		btn1.addEventListener('click', function(){
			searchPOI(type,id);
		});
		btn1.setAttribute("id", "searchPOI");
		document.getElementById("SearchMenu").appendChild(btn1);
	}
	if(type == "AOI"){
		var btn1 = document.createElement("BUTTON");  
		btn1.className = "ui button";
		btn1.innerHTML = "景點";
		btn1.addEventListener('click', function(){
			searchPOI(type,id);
		});
		btn1.setAttribute("id", "searchPOI");
		document.getElementById("SearchMenu").appendChild(btn1);
	}
}
async function getBeacon(mid){
	var beacon = [];
	await $.ajax({
	  url: "/api/Beacon/getBeacon/",
	  type: "get", //send it through get method
	  data: { 
		id: mid
	  },
	  success: function(response) {
		response.forEach(function(value){
			tmp = {
				"x":value.Beacon_X,
				"y":value.Beacon_Y,
			};
			beacon.push(tmp);
		});
	  },
	  error: function(xhr) {
		//Do Something to handle error
	  }
	});
	for(i = 0;i < beacon.length;++i){
		var icon = document.createElement("I");  
		icon.className="circle icon";
		icon.style.position = "absolute";
		icon.style.top = ((beacon[i].y)*1.25-10)+"px";
		icon.style.left = ((beacon[i].x)*1.25-10)+"px";
		document.getElementById("beacons").appendChild(icon);
	}
	
}
// Show Soi/Aoi/Loi on the google map
function getData(){
    var index = document.getElementById("search").value;
    if(index == "SOI"){
		document.getElementById("ListContent").innerHTML = " ";
        $.get("/api/SOI/getSoi/", function(data, status){
		var marker = []; 
		var content = [];
		var id = [];
		data.forEach(function(value){
			var tmp = {
				"name" : value.name,
				"description" : value.description,
			}
			var position = {
				lat:  parseFloat(value.lat),
				lng:  parseFloat(value.lng)
			};
			marker.push(position);
			content.push(tmp);
			id.push(value.s_id);
		});
			geocoder = new google.maps.Geocoder();
			placeMarker(marker,"SOI",content,id);
			for(i = 0;i< marker.length;++i){
				geocoder.geocode({ 'latLng': marker[i]}, function (results, status) {
					if (status === google.maps.GeocoderStatus.OK) {
						map.setCenter(results[0].geometry.location);
						map.setZoom(17);
					}
					// 經緯度資訊錯誤
					else {
						alert("Google 無法辨視此位置 ");
					}
				});
			}
			
		});
    }
    else if(index == "AOI"){
		document.getElementById("ListContent").innerHTML = " ";
		$.get("/api/AOI/getAoiInGoogleMap/", function(data, status){
		var marker = [];
		var content = [];
		var id = [];
		data.forEach(function(value){
			var tmp = {
				"name" : value.name,
				"description" : value.description,
			}
			var position = {
				lat:  parseFloat(value.lat),
				lng:  parseFloat(value.lng)
			};
			marker.push(position);
			content.push(tmp);
			id.push(value.a_id);
		});
			geocoder = new google.maps.Geocoder();
			placeMarker(marker,"AOI",content,id);
			for(i = 0;i< marker.length;++i){
				geocoder.geocode({ 'latLng': marker[i]}, function (results, status) {
					if (status === google.maps.GeocoderStatus.OK) {
						map.setCenter(results[0].geometry.location);
						map.setZoom(17);
					}
					// 經緯度資訊錯誤
					else {
						alert("Google 無法辨視此位置 ");
					}
				});
			}
		});
    }
    else if(index == "LOI"){
		document.getElementById("ListContent").innerHTML = " ";
		$.get("/api/LOI/getLoiInGoogleMap/", function(data, status){
		var marker = []; 
		var content = [];
		var id = [];
		data.forEach(function(value){
			var tmp = {
				"name" : value.name,
				"description" : value.description,
			}
			var position = {
				lat:  parseFloat(value.lat),
				lng:  parseFloat(value.lng)
			};
			marker.push(position);
			content.push(tmp);
			id.push(value.l_id);
		});
			geocoder = new google.maps.Geocoder();
			placeMarker(marker,"LOI",content,id);
			for(i = 0;i< marker.length;++i){
				geocoder.geocode({ 'latLng': marker[i]}, function (results, status) {
					if (status === google.maps.GeocoderStatus.OK) {
						map.setCenter(results[0].geometry.location);
						map.setZoom(17);
					}
					// 經緯度資訊錯誤
					else {
						alert("Google 無法辨視此位置 ");
					}
				});
			}
		});
    }

}

//get poi data
async function searchPOI(type,id){
	document.getElementById("ListContent").innerHTML = " ";
	document.getElementById("icons").innerHTML = " ";
	var i;
	var POI = [];
	await $.ajax({
	  url: "/api/POI/getPoi/",
	  type: "get", //send it through get method
	  data: { 
		type: type,
		id: id
	  },
	  success: function(response) {
		response.forEach(function(value){
			tmp = {
				"id":value.p_id,
				"name":value.name,
				"description":value.description,
				"x":value.x,
				"y":value.y,
				"order":value.order
			};
			POI.push(tmp);
		});
	},
	  error: function(xhr) {
		//Do Something to handle error
	  }
	});
	for(i = 0;i < POI.length;++i){
		var icon = document.createElement("I");  
		icon.className="map marker alternate icon";
		icon.style.position = "absolute";
		icon.style.top = (POI[i].y)*1.25+"px";
		icon.style.left = (POI[i].x)*1.25+"px";
		icon.id = POI[i].id;
		icon.setAttribute("description",POI[i].description);
		icon.addEventListener('click', function(){
			getPOIDetail($(this).attr('id'),$(this).attr('description'));
			$('#PoiDetail').modal('show');
		});
		document.getElementById("icons").appendChild(icon);
		var li = document.createElement("LI");
		li.innerHTML = POI[i].name;
		
		document.getElementById("ListContent").appendChild(li);
	}
	$('#content').removeClass("hidden");
	document.getElementById("type").innerHTML = "POI List";
	 
}

//get loi data
async function searchLOI(type,id){
	document.getElementById("ListContent").innerHTML = " ";
	document.getElementById("icons").innerHTML = " ";
	var LOI =[];
	await $.ajax({
	  url: "/api/LOI/getLoiInSOI/",
	  type: "get", //send it through get method
	  data: { 
		id: id
	  },
	  success: function(response) {  
		response.forEach(function(value){
			tmp = {
				"lid":value.id,
				"name":value.name,
				"description":value.description,
				"x":value.X,
				"y":value.Y
			};
			LOI.push(tmp);
		});
	  },
	  error: function(xhr) {
		//Do Something to handle error
	  }
	});
	for(i = 0;i < LOI.length;++i){
		var icon = document.createElement("I");  
		icon.className="map marker icon";
		icon.style.position = "absolute";
		icon.style.top = (LOI[i].y)*1.25+"px";
		icon.style.left = (LOI[i].x)*1.25+"px";
		icon.id = Number(LOI[i].lid);
		icon.addEventListener('click', function(){
			getDetail("LOI",$(this).attr('id'));
		});
		document.getElementById("icons").appendChild(icon);
		var li = document.createElement("LI");
		li.innerHTML = LOI[i].name;
		document.getElementById("ListContent").appendChild(li);
	}
	$('#content').removeClass("hidden");
	document.getElementById("type").innerHTML = "LOI List";
}

//get aoi data
async function searchAOI(type,id){
	document.getElementById("ListContent").innerHTML = " ";
	document.getElementById("icons").innerHTML = " ";
	var AOI =[];
	await $.ajax({
	  url: "/api/AOI/getAoiInSOI/",
	  type: "get", //send it through get method
	  data: { 
		id: id
	  },
	  success: function(response) {
		response.forEach(function(value){
			tmp = {
				"name":value.name,
				"description":value.description,
				"x":value.X,
				"y":value.Y,
				"aid":value.id,
			};
			AOI.push(tmp);
		});
	  },
	  error: function(xhr) {
		//Do Something to handle error
	  }
	});
	for(i = 0;i < AOI.length;++i){
		var icon = document.createElement("I");  
		icon.className="map marker icon";
		icon.style.position = "absolute";
		icon.style.top = (AOI[i].y)*1.25+"px";
		icon.style.left = (AOI[i].x)*1.25+"px";
		icon.id = Number(AOI[i].aid);
		icon.addEventListener('click', (function(icon, i) {
			return function() {
			getDetail("AOI",$(this).attr('id'));
			}
		 })(icon, i));
		
		document.getElementById("icons").appendChild(icon);
		var li = document.createElement("LI");
		li.innerHTML = AOI[i].name;
		document.getElementById("ListContent").appendChild(li);
	}
	$('#content').removeClass("hidden");
	document.getElementById("type").innerHTML = "AOI List";
}

async function getPOIDetail(id,description){
	document.getElementById("poi_img").src = "";
	document.querySelector("#poi_video > source").src = " ";
	document.getElementById("poi_name").innerHTML="";
	document.getElementById("poi_description").innerHTML=description;
	await $.ajax({
	  url: "/api/Media/getPoiMedia/",
	  type: "get", //send it through get method
	  data: { 
		id: id
	  },
	  success: function(response) {
		response.forEach(function(value){
			if(value.TYPE == "image")
				document.getElementById("poi_img").src = "../.."+value.url;
			else if(value.TYPE == "video"){
				$('#poi_video').removeClass("hidden");
				document.querySelector("#poi_video > source").src = "../.."+value.url;
				document.getElementById("poi_video").load();
			}
			document.getElementById("poi_name").innerHTML = value.name; 
		});
	  },
	  error: function(xhr) {
		//Do Something to handle error
	  }
	});
}
function zoomin(){
    var myImg = document.getElementById("mapImg");
	var icons = document.getElementById("icons").querySelectorAll("i");
	var beacons = document.getElementById("beacons").querySelectorAll("i");
    var imgSrc = $("#mapImg").attr('src');
    var currWidth = myImg.clientWidth;
    myImg.style.width = (currWidth + 100) + "px";
	var scale = (currWidth+100)/currWidth;
	for(i=0;i < icons.length;++i){
		icons[i].style.left = (icons[i].offsetLeft * scale) +"px";
		icons[i].style.top = (icons[i].offsetTop * scale) +"px";
	}
	for(i=0;i < beacons.length;++i){
		beacons[i].style.left = (beacons[i].offsetLeft * scale) +"px";
		beacons[i].style.top = (beacons[i].offsetTop * scale) +"px";
	}
	$('#ZoomOut').removeClass("disabled");
    if(currWidth >= 1000){
        $('#ZoomIn').addClass("disabled");
    }else if(currWidth >= 700){
        console.log("change");
    }
    console.log(imgSrc);
    console.log(currWidth)
}
function zoomout(){
    var myImg = document.getElementById("mapImg");
	var icons = document.getElementById("icons").querySelectorAll("i");
	var beacons = document.getElementById("beacons").querySelectorAll("i");
    var currWidth = myImg.clientWidth;
    var imgSrc = $("#mapImg").attr('src');
    myImg.style.width = (currWidth - 100) + "px";
	var scale = (currWidth-100)/currWidth;
	for(i=0;i < icons.length;++i){
		icons[i].style.left = icons[i].offsetLeft * scale +"px";
		icons[i].style.top = icons[i].offsetTop * scale +"px";
	}
	for(i=0;i < beacons.length;++i){
		beacons[i].style.left = (beacons[i].offsetLeft * scale) +"px";
		beacons[i].style.top = (beacons[i].offsetTop * scale) +"px";
	}
		$('#ZoomIn').removeClass("disabled");
    if(currWidth <= 500){
        console.log("max");
        $('#ZoomOut').addClass("disabled");
    }else if(currWidth <= 600){
		
    }else if(currWidth <= 700){
		 
    }else if(currWidth <= 900){
        console.log("change");
    }
    console.log(currWidth-100);
}

async function getDiffMap(mid){
	var diffmap = [];
	await $.ajax({
	  url: "/api/Map/getDiffMap/",
	  type: "get", //send it through get method
	  data: { 
		id: mid
	  },
	  success: function(response) {
		response.forEach(function(value){
			tmp = {
				"scale":value.scale,
				"url":value.url,
			};
			diffmap.push(tmp);
		});
	  },
	  error: function(xhr) {
		//Do Something to handle error
	  }
	});
	return diffmap[0].url
}
function Back(){
    $('#googleMap').removeClass("hidden");
    $('#rep').addClass("hidden");
	$('#SearchField').closest("DIV").removeClass("hidden");
	$('#content').addClass("hidden");
	document.getElementById("ListContent").innerHTML = " ";
	document.getElementById("icons").innerHTML = " ";
	document.getElementById("icons").style = " ";
	document.getElementById("beacons").style = " ";
	document.getElementById("beacons").innerHTML = " ";
	document.getElementById("SearchMenu").innerHTML = " ";
}