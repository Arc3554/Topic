$('#map_img0').on('change', function(e){      
    const file = this.files[0];
    const objectURL = URL.createObjectURL(file);
    $('#imagePreview0').attr('src', objectURL);
    });
var counter = 1;
var map_counter = 1;
var beacon_counter = 0;
var poi_counter = 0;
var check_tab = 1;
var add_size = [];
var check_beacon = new Boolean(false);
function getGroup(){
	$.get("/api/LOI/getGroupLeader/", function(data, status){
		data.forEach(function(value){
			name = value.name;
			id = value.id;
			var item = document.createElement('option');
			item.value = id;
			item.text = name;
			group.add(item);
		});
	});
}
$(document).ready(function(){
    $('.ui.modal')
    .modal({
        inverted: true
    })
    .modal('attach events', '.test.button','show')
    ;
    $(".nav-tabs").on("click", "span", function () {
        $(this).parent().remove();
        $(".nav-tabs li").children('a').first().click();
        map_counter--;
    });
	$("#addPOI").click(async function(){
		var order = 1;
		$("#ListContent ul").html("");
        await $.get("/api/POI/getPoi/", function(data, status){
            data.forEach(function(value){
			title = value.poi_title;
			var bt = document.createElement('button');
			 
			bt.className="list-group-item";
			bt.innerHTML = title;
			
			var span = document.createElement('span');
			span.className = "badge badge-light";
			bt.addEventListener("click",()=>{
			bt.classList.toggle('active');
			if(bt.classList.contains("active") == true){
				span.innerHTML = order;
				bt.appendChild(span);
				order ++;
			}
			else{
				if(span.innerHTML != order && span.innerHTML == 1){
					span.remove();
					var tmps = document.getElementsByClassName("badge badge-light");
					Array.prototype.forEach.call(tmps, function(tmp) {
						tmp.innerHTML = tmp.innerHTML - 1;
					});
					order--;
				}
				else if(span.innerHTML != order && span.innerHTML != 1){
					var index = span.innerHTML; 
					span.remove();
					var tmps = document.getElementsByClassName("badge badge-light");
					Array.prototype.forEach.call(tmps, function(tmp) {
						if(tmp.innerHTML > index)
						tmp.innerHTML = tmp.innerHTML - 1;
					});
					order--;
				}
				else{
					span.remove();
					order--;
				}
				
			}
			
			});
			$("#ListContent ul").append(bt);
			});
		});
	});
	
});



//img preview
function img_pre(input){
    $('#map_img'+input).on('change', function(e){      
        const file = this.files[0];
        var objectURL;
        try{
            objectURL = URL.createObjectURL(file);
        }
        catch{
            console.log("file error");
        }
        $('#imagePreview'+input).attr('src', objectURL);
        });
}

//get active tab
function getTabID(clicked){
    var temp;
    console.log(clicked);
    temp = clicked.split("_map");
    delete temp[0];
    check_tab = temp[1];
	console.log(check_tab);
}

//diff tab content
function addMap(){
    map_counter++;
    var li = document.createElement("li");
    var a = document.createElement("a");
    var span = document.createElement("span");
    var div = document.createElement("div");
    div.id = "upload_map"+map_counter;
    div.className = "container tab-pane";
    div.innerHTML = `
    <br>
    <h2 class="ui header" >
    <i class="map icon"></i>
    <div class="content" >
    製作景線地圖
    </div>
    </h2>
    <p></p>
    <p></p>
    <form class="ui form" method="POST"  id = "make_loi${map_counter}" enctype="multipart/form-data">
        <div class="inline field">
            <label >標題</label>
            <input style="width: 158px;"type="text" name="map_title" placeholder="">
        </div>
        <div class="inline field">
            <label >描述</label>
            <textarea style="width: 158px;height:10px;"type="text" name="map_description" placeholder=""></textarea>
        </div>
        <div class="inline field">
            <label >樓層</label>
            <input style="width: 158px;"type="text" name="floor" placeholder="">
        </div>
        <div class="inline field" >
            <label >上傳地圖</label>
            <input style="width: 158px;"type="file" name="mapInputs[0]" placeholder="" class="map_img" id="map_img0" onClick="img_pre(0)">
            <img id="imagePreview0" style="width: 400px;height: 100%;">
            <i class="thumbtack icon" id="beacon"></i>
            </img>
        </div>
        <div class="inline field">
            <label >比例尺</label>
            <input style="width: 158px;"type="text" name="scale[0]" placeholder="">
        </div>
        <div class="inline field" id ="submit_btn${map_counter}">
        <button class="ui primary button" type="button" id="map_submit${map_counter}" >Submit</button>
        <button type="reset" class="ui button">Clear</button>
        </div>
    </form>
    </div>`;
    var content = document.getElementById("tab-content");
    content.appendChild(div);
    a.className = "nav-link";
    a.setAttribute("data-toggle","tab");
    a.setAttribute("href","#upload_map"+map_counter);
    a.id = "new_map"+map_counter;
    a.setAttribute("onclick","getTabID(this.id)");
    a.appendChild(document.createTextNode("自製地圖"+map_counter));
    span.innerHTML = "x";
    li.appendChild(a);
    li.appendChild(span);
    li.className = "nav-item";
    document.getElementById('add_map').before(li);
}

//add diff scale map
function addInput(){
    var newdiv = document.createElement('div');
    newdiv.className = "inline field";
    newdiv.innerHTML = "<label >上傳地圖</label> " + "<input style='width: 158px;' type='file' name='mapInputs["+counter+"]' class='map_img' id='map_img"+counter+"' onClick=\"img_pre("+counter+")\"> <input type='button' value='x' onClick='removeInput(this);'><img id='imagePreview"+counter+"' style='width: 400px;height: 100%;'><br><label >比例尺</label> " + "<input style='width: 158px;' type='text' name='scale["+counter+"]'id='scale"+counter+"'> ";
   
	document.getElementById('submit_btn'+check_tab).before(newdiv);
    counter++;
}

//remove  scale map
function removeInput(btn){
    btn.parentNode.remove();
}

//add beacon content
function addBeacon(){
    check_beacon = true;
    var newdiv = document.createElement('div');
    newdiv.className = "inline field";
    newdiv.innerHTML = "<label >beacon"+beacon_counter+"座標(x)</label> " + "<input readonly='value' style='width: 158px;' type='text' name='beacon_x["+beacon_counter+"]' id='beacon_x"+beacon_counter+"'>" +"<label >beacon"+beacon_counter+"座標(y)</label> " + "<input readonly='value' style='width: 158px;' type='text' name='beacon_y["+beacon_counter+"]' id='beacon_y"+beacon_counter+"'> <input type='button' value='+' onClick='getMapPoint("+beacon_counter+",0)'><input type='button' value='x' onClick='removeBeacon(this);'>";
    document.getElementById("submit_btn"+check_tab).before(newdiv);
    beacon_counter++;
}


function removeBeacon(btn){
    btn.parentNode.remove();
    beacon_counter--;
    if(beacon_counter===1){
        check_beacon = false;
    }
}

//get  position on the img
function getMapPoint(num,type){
    var content = document.getElementById('content');
    var form_img = document.getElementById('make_loi');
    var img_preview = document.getElementById('imagePreview0');
	var temp_t = -1;
	if(temp_t != type ){
			console.log("123");
			$("#imagePreview0").prop("onclick", null).off("click");
	}
	temp_t = type;
	if(typeof num !== 'undefined'){ 
			temp= num;
		}
		
			$("#imagePreview0").on("click", function () {
				console.log(temp_t);
				var x = event.pageX-content.offsetLeft - form_img.offsetLeft -img_preview.offsetLeft;
				var y = event.pageY-content.offsetTop - form_img.offsetTop-img_preview.offsetTop;
				var d = document.getElementById('beacon');
				d.style.opacity=1;
				d.style.left = x +img_preview.offsetLeft- d.offsetWidth/2 +'px';
				d.style.top = y+img_preview.offsetTop - d.offsetHeight+'px';
				if(temp_t == 0){
					console.log("0");
					$("#beacon_x"+temp).val(x);
					$("#beacon_y"+temp).val(y);
					console.log("b_X:"+$("#beacon_x"+temp).val(x));
					console.log("b_Y:"+$("#beacon_y"+temp).val(y));
				}
				if(temp_t == 1){
					console.log("1");
					$("#POI_x"+temp).val(x);
					$("#POI_y"+temp).val(y);
					console.log("p_X:"+$("#POI_x"+temp).val(x));
					console.log("p_Y:"+$("#POI_y"+temp).val(y));
				}
			});
}


function ShowPoiList(){
	var list = document.getElementsByClassName("list-group-item active");
	var orders = document.getElementsByClassName("badge badge-light");
	var j,index;
	for(i = 0; i < list.length; i++){
		for (j = 0 ;j < list.length; j++){
			if(orders[j].innerHTML == i+1){
				index = j;
			}
		}
		var newdiv = document.createElement('div');
			newdiv.className = "inline field";
			newdiv.innerHTML =`<label id=POI_name${poi_counter}>${orders[index].innerText}.${list[index].innerText.slice(0, list[index].innerText.length-1)}座標(x)</label><input readonly='value' style='width: 158px;' type='text' name='POI_x[${poi_counter}]' id='POI_x${poi_counter}'><label >${list[index].innerText.slice(0, list[index].innerText.length-1)}座標(y)</label><input readonly='value' style='width: 158px;' type='text' name='POI_y[${poi_counter}]' id='POI_y${poi_counter}'> <input type='button' value='+' onClick='getMapPoint(${poi_counter},1)'>`;
			document.getElementById('submit_btn'+check_tab).before(newdiv);
			poi_counter++;		
	}
}
function error(type, str) {
    $(type + '-error').text(str);
    $(type).addClass('err');
}

function clear() {
    $('#title-error').text("");
    $('#description-error').text("");
    $('#floor-error').text("");
    $('#map_img-error').text("");
    $('#scale-error').text("");
    $('#title').removeClass('err');
    $('#description').removeClass('err');
    $('#floor').removeClass('err');
    $('#map_img').removeClass('err');
    $('#scale').removeClass('err');

}

function check() {
    clear();
    const title = $('#title').val();
    const description = $('#description').val();
    const floor = $('#floor').val();
    const map_img = $('#map_img0').val();
    const scale = $('#scale0').val();
    let ans = true;

    if (title == "") {
        error("#title", '此為必填欄位');
        ans = false;
    }

    if (description == "") {
        error("#description", '此為必填欄位');
        ans = false;
	}
    if (floor == "") {
        error("#floor", '此為必填欄位');
        ans = false;
    } 
    if (map_img == "") {
        error("#map_img", '此為必填欄位');
        ans = false;
    } 
    if (scale == "") {
        error("#scale", '此為必填欄位');
        ans = false;
    }
    return ans;

}
//Ajax jQuery
function upload() {
	if (check() == true) {
		var data = new FormData();
		var title = $('#title').val();
		var description = $('#description').val();
		var floor = $('#floor').val();
		var map = $('#map_img0').prop('files')[0];
		var scale = $('#scale0').val();
		var group = $('#group').val(); //return id
		var i ;
		var diffmap = [];
		for (i = 1;i <counter;++i){
			var tmp = {
				"scale":$('#scale'+i).val()
			}
			diffmap.push(tmp);
			data.append('map'+i,$('#map_img'+i).prop('files')[0]);
		}
		var beacon = [];
		for (i = 0;i <beacon_counter;++i){
				var tmp = {
					"num":i,
					"x":$('#beacon_x'+i).val(),
					"y":$('#beacon_y'+i).val()
				}
				beacon.push(tmp);
		}
		var poi = [];
		for (i = 0;i <poi_counter;++i){
				var t = $('#POI_name'+i).text().split("座標(x)");
				var t = t[0].split(".");
				var tmp = {
					"name":t[1],
					"x":$('#POI_x'+i).val(),
					"y":$('#POI_y'+i).val(),
					"order":t[0]
				}
				console.log(tmp);
				poi.push(tmp);
		}
		data.append('map',map);
		data.append('scale',scale);
		data.append('title',title);
		data.append('description',description);
		data.append('floor',floor);
		data.append('group',group);
		for (i=0;i<poi.length;++i){
			data.append('pois',JSON.stringify(poi));
		}
		for (i=0;i<beacon.length;++i){
			data.append('beacons',JSON.stringify(beacon));
		}
		for (i=0;i<diffmap.length;++i){
			data.append('diffmaps',JSON.stringify(diffmap));
		}
		data.append("counter",counter-1);
		data.append("beacon_counter",beacon_counter);
		data.append("poi_counter",poi_counter);
		$.ajax({
			url:'/upload_profile/make_loi/', 
			type: 'POST',
			data: data,
			cache: false,
			processData:false,
			contentType: false,
			success: function(data) {
				alert('success');
				window.location = "/upload_profile/make_loi/";
			},
			error: function (data) {
				HandleErrUpload(ids);
			},
		});
	}
}