function error(type, str) {
    $(type + '-error').text(str);
    $(type).addClass('err');
}

function clear() {
    $('#account-error').text("");
    $('#password-error').text("");
    $('#account').removeClass('err');
    $('#password').removeClass('err');
}

function check() {
    clear();
	var english = /^[A-Za-z0-9]+$/;
    const account = $('#account').val().trim();
    const password = $('#password').val().trim();
    let ans = true;

    if (account == "") {
        error("#account", '未輸入帳號');
        ans = false;
    }else {
        if (!english.test(account)) {
            error("#account", '帳號只能包含英文和數字');
            ans = false;
        }
    }

    if (password == "") {
        error("#password", '未輸入密碼');
        ans = false;
    }
    return ans;

}
$('#login_btn').click((event) => {
    event.preventDefault()
    if (check() == true) {
        $.post('/upload_profile/login/', {
            username: $('#login input[name=username]').val().trim(),
            password: $('#login input[name=password]').val().trim()
        }, (res) => {
          
            console.log(res);
			if(res[0] === true){
				window.location = "/upload_profile/index/";
			} else {
                alert(res[1]);
            }
        });
    }
});
