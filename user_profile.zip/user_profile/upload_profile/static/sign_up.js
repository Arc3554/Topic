function error(type, str) {
    $(type + '-error').text(str);
    $(type).addClass('err');
}

function clear() {
    $('#name-error').text("");
    $('#email-error').text("");
    $('#password-error').text("");
    $('#password2-error').text("");
    $('#gender-error').text("");
	$('#role-error').text("");
    $('#name').removeClass('err');
    $('#email').removeClass('err');
    $('#password').removeClass('err');
    $('#password2').removeClass('err');
    $('#gender').removeClass('err');
	$('#role').removeClass('err');

}

function check() {
    clear();
    var english = /^[A-Za-z0-9]+$/;
    var phonenumber = /^09[0-9]{8}$/
    const name = $('#username').val();
    const email = $('#email').val();
    const password = $('#password').val();
    const password2 = $('#password2').val();
    const gender = $('#gender').val();
	const role = $('#role').val();
    let ans = true;

    if (name == "") {
        error("#name", '此為必填欄位');
        ans = false;
    }else {
        if (!english.test(name)) {
            error("#name", '帳號只能包含英文和數字');
            ans = false;
        }
    }

    if (email == "") {
        error("#email", '此為必填欄位');
        ans = false;
    } 
    if (password == "") {
        error("#password", '此為必填欄位');
        ans = false;
    } else {
        if (password.length < 6) {
            error("#password", '密碼需大於六個字元');
            ans = false;
        } else if (password.length > 10) {
            error("#password", '密碼需小於十個字元');
            ans = false;
        }
    }
    if (password2 == "") {
        error("#password2", '此為必填欄位');
        ans = false;
    } else {
        if (password != password2) {
            error("#password2", '密碼與上方不符');
            ans = false;
        }
    }

    if (gender == "") {
        error("#gender", '此為必填欄位');
        ans = false;
    } 
	if (role == "") {
        error("#role", '此為必填欄位');
        ans = false;
    }
	
    return ans;

}

$('#sign_btn').click((event) => {
    event.preventDefault();
    if (check() == true) {
        $.post('/upload_profile/sign_up/', {
            name: $('#signup input[name=username]').val(),
            password: $('#signup input[name=password]').val(),
            email: $('#signup input[name=email]').val(),
            gender: $('#signup select[name=gender]').val(),
			role: $('#signup select[name=role]').val()
        }, (res) => {
			if(res[0] === true){
				window.location = "/upload_profile/index/";
			} else {
                alert(res[1]);
            }
        });
        
    }

});
$('#logout_btn').click((event) => {
});