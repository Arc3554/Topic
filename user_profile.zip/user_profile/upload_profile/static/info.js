async function getData(){
    var index = document.getElementById("search").value;
	author = document.getElementById("contributor").innerText;
	if(author != null){
		if(index == "SOI"){
			var soi = [];
			document.getElementById("ListContent").innerHTML = " ";
			await $.ajax({
			  url: "/api/SOI/getSoi/",
			  type: "get", //send it through get method
			  data: { 
				author: author,
			  },
			  success: function(response) {
				response.forEach(function(value){
				tmp = {
					"id":value.id,
					"name":value.name,
					"intro":value.intro,
					"map":value.MAP_ID
				};
				soi.push(tmp);
			})		
			  },
			  error: function(xhr) {
				//Do Something to handle error
			  }
			});
			for(i=0;i<soi.length;++i){
				var li = document.createElement("LI");
				li.innerHTML = soi[i].name;	
				document.getElementById("ListContent").appendChild(li);
			}
			$('#content').removeClass("hidden");
			document.getElementById("type").innerHTML = "SOI List";
		}
		else if(index == "AOI"){
			var aoi = [];
			document.getElementById("ListContent").innerHTML = " ";
			await $.ajax({
			  url: "/api/AOI/getAoi/",
			  type: "get", //send it through get method
			  data: { 
				author: author,
			  },
			  success: function(response) {
				response.forEach(function(value){
				tmp = {
					"id":value.id,
					"name":value.name,
					"intro":value.intro,
					"map":value.MAP_ID
				};
				aoi.push(tmp);
			})		
			  },
			  error: function(xhr) {
				//Do Something to handle error
			  }
			});
			for(i=0;i<aoi.length;++i){
				var li = document.createElement("LI");
				li.innerHTML = aoi[i].name;	
				document.getElementById("ListContent").appendChild(li);
			}
			$('#content').removeClass("hidden");
			document.getElementById("type").innerHTML = "AOI List";
		}
		else if(index == "LOI"){
			var loi = [];
			document.getElementById("ListContent").innerHTML = " ";
			await $.ajax({
			  url: "/api/LOI/getLoi/",
			  type: "get", //send it through get method
			  data: { 
				author: author,
			  },
			  success: function(response) {
				response.forEach(function(value){
				tmp = {
					"id":value.id,
					"name":value.name,
					"intro":value.intro,
					"map":value.MAP_ID
				};
				loi.push(tmp);
			})		
			  },
			  error: function(xhr) {
				//Do Something to handle error
			  }
			});
			for(i=0;i<loi.length;++i){
				var li = document.createElement("LI");
				li.innerHTML = loi[i].name;	
				document.getElementById("ListContent").appendChild(li);
			}
			$('#content').removeClass("hidden");
			document.getElementById("type").innerHTML = "LOI List";
		}
		else if(index == "POI"){
			var poi = [];
			document.getElementById("ListContent").innerHTML = " ";
			await $.ajax({
			  url: "/api/POI/getPoi/",
			  type: "get", //send it through get method
			  data: { 
				author: author,
			  },
			  success: function(response) {
				response.forEach(function(value){
				tmp = {
					"id":value.id,
					"name":value.name,
					"intro":value.intro,
					"map":value.MAP_ID
				};
				loi.push(tmp);
			})		
			  },
			  error: function(xhr) {
				//Do Something to handle error
			  }
			});
			for(i=0;i<loi.length;++i){
				var li = document.createElement("LI");
				li.innerHTML = loi[i].name;	
				document.getElementById("ListContent").appendChild(li);
			}
			$('#content').removeClass("hidden");
			document.getElementById("type").innerHTML = "LOI List";
		}
	}
	else{
		alert("請先登入");
	}
}