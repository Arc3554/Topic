image_count = 0; //多媒體
sound_count = 0; //語音導覽
finalFiles = []; //多媒體檔案(圖)
var md1 = 4;
var md2 = 0;

$(document).ready(function () {
        $('.upload_nothing').append('<input class="sound_val" name="sounds" value="0" hidden>');
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            console.log('Great success! All the File APIs are supported.')
        } else {
            alert('The File APIs are not fully supported in this browser.');
        }
        $('#clear').click(function () {
            $('input[type=radio][name=media]').value == 'none';
            $('input[type=radio][name=sounds]').value == 'none';
            var upload_none = $('.upload_none').empty();
            var upload_image = $('.upload_image').empty();
            var upload_video = $('.upload_video').empty();
            var upload_audio = $('.upload_audio').empty();
            var upload_none = $('.upload_nothing').empty();
            var upload_audio = $('.upload_sound').empty();
        });
        $('#make_poiform').submit((event) => { SubmitForm(event) });
        $('input[type=radio][name=media]').change(function () {
            var restrict = $('#restrict').empty();
            $('.alert-danger').hide();
            var upload_none = $('.upload_none').empty();
            var upload_image = $('.upload_image').empty();
            var upload_video = $('.upload_video').empty();
            var upload_audio = $('.upload_audio').empty();
            if (this.value == 'image') {
                restrict.html('允許上傳gif/jpg/png/jpeg格式的圖片，圖片檔案大小不能超過2M(可上傳5張照片)');
                upload_image.append('<input class="media_val" name="media" value="1" hidden>');
                upload_image.append('<input type="file" name="image_file" accept=".gif,.jpg,.png,.jpeg" id="image_file" multiple>');
                upload_image.append('<output id="image_list">');
                md1=1;
                var el = document.getElementById('image_file');
                if (el) {
                    el.addEventListener('change', handleFileSelect, false);
                }
            } else if (this.value == 'video') {
                image_count = 0;
                restrict.html('允許上傳mp4/avi/mov格式的錄音檔，檔案大小不能超過5M');
                upload_video.append('<input class="media_val" name="media" value="4" hidden>');
                upload_video.append('<input type="file" name="video_file" accept=".mp4,.avi, .mov" id="video_file">');
                upload_video.append('<video controls id="disp_video"></video>');
                md1=2;
                var el = document.getElementById('video_file');
                if (el) {
                    el.addEventListener('change', handleVideo, false);
                }
            } else if (this.value == 'audio') {
                image_count = 0;
                restrict.html('允許上傳amr/3gpp/aac/mp3格式的錄音檔，檔案大小不能超過5M');
                upload_audio.append('<input class="media_val" name="media" value="2" hidden>');
                upload_audio.append('<input type="file" name="audio_file" accept=".amr,.3gpp,.aac,.mp3" id="audio_file">');
                upload_audio.append('<audio controls id="disp_audio"></audio>');
                md1=3;
                var el = document.getElementById('audio_file');
                if (el) {
                    el.addEventListener('change', handleAudio, false);
                }
            } else if (this.value == 'none'){
                md1=4;
            }
            
        });
        $('input[type=radio][name=sounds]').change(function () {
            var restrict1 = $('#restrict1').empty();
            $('.alert-danger').hide();
            var upload_nothing = $('.upload_nothing').empty();
            var upload_sound = $('.upload_sound').empty();
            if (this.value == 'sound') {
                sound_count = 0;
                restrict1.html('允許上傳amr/3gpp/aac格式的錄音檔，檔案大小不能超過5M');
                upload_sound.append('<input class="sound_val" name="sounds" value="8" hidden>');
                upload_sound.append('<input type="file" name="sound_file" accept=".amr,.3gpp,.aac,.mp3" id="sound_file">');
                upload_sound.append('<audio controls id="disp_sound"></audio>');
                md2=4;
                var el = document.getElementById('sound_file');
                if (el) {
                    el.addEventListener('change', handleSound, false);
                }
            } else if (this.value == 'none') {
                $('.upload_nothing').empty();
                restrict1.html('無語音導覽檔案');
                sound_count = 0;
                md2=0;
                upload_nothing.append('<input class="sound_val" name="sounds" value="0" hidden>');
            }
        });
});

function handleFileSelect(evt) {
    $('.alert-danger').hide();
    if (!window.File || !window.FileReader || !window.FileList || !window.Blob) {
        alert('The File APIs are not fully supported in this browser.');
        return;
    }
    var files = evt.target.files; // FileList object
    $.each(this.files, function (idx, elm) {
        finalFiles[idx] = elm;
    });
    // Loop through the FileList and render image files as thumbnails.
    for (var i = 0, f; f = files[i]; i++) {
        // Only process image files.
        if (!f.type.match('image.*')) {
            continue;
        }
        if (image_count < 5) { //5張限制
            var reader = new FileReader();
            // Closure to capture the file information.
            reader.onload = (function (theFile) {
                return function (e) {
                    // Render thumbnail.
                    limit_size = theFile.size / 1048576;
                    var image = new Image();

                    //create new image and coupute the ratio to compress
                    var ratio = 1 / Math.pow(limit_size, 0.5);
                    var canvas = document.createElement("canvas");
                    var datatype = e.target.result.split(',')[0].split(':')[1].split(';')[0];

                    //when image load complete , use canvas to resize image
                    image.onload = function () {
                        var ctx = canvas.getContext("2d");
                        EXIF.getData(image, function () {
                            var orientation = EXIF.getTag(image, 'Orientation');
                            switch (orientation) {
                                case 6:
                                    canvas.width = image.height;
                                    canvas.height = image.width;
                                    if (limit_size > 2) {
                                        canvas.width = canvas.width * ratio;
                                        canvas.height = canvas.height * ratio;
                                    }
                                    var x = canvas.width / 2;
                                    var y = canvas.height / 2;
                                    ctx.rotate(90 * Math.PI / 180);
                                    ctx.translate(0, -x * 2)
                                    break;
                                default:
                                    if (limit_size > 2) {
                                        canvas.width = image.width * ratio;
                                        canvas.height = image.height * ratio;
                                    }
                                    else {
                                        canvas.width = image.width;
                                        canvas.height = image.height;
                                    }
                            }
                        });
                        if (limit_size > 2) {
                            ctx.scale(ratio, ratio);
                        }
                        ctx.drawImage(image, 0, 0);
                        NewImageInsert(canvas.toDataURL(datatype), 205 * canvas.height / canvas.width);
                    };
                    image.src = e.target.result;
                    //create the new span contains image in output
                    function NewImageInsert(dataURL, height) {
                        var span = document.createElement('span');
                        span.className = "imgspan";
                        span.innerHTML = ['<img id="thumb' + theFile.name + '" name="thumb" style="height: ' + height + 'px;width: 205px; margin: 10px 5px 0 0;" src="', dataURL,
                            '" title="', escape(theFile.name), '"/> \
                      <button type="button" style="display: block;width: 205px;background: #4bafa9; color: white; text-align:center; \
                      cursor: pointer;" id="remove' + theFile.name + '" onclick="rmvImg(this,\'thumb' + theFile.name + '\')">\u522a\u9664\u5716\u7247</button>'  //刪除圖片
                        ].join('');
                        document.getElementById('image_list').insertBefore(span, null);
                    }
                };
            })(f);
            // Read in the image file as a data URL.
            reader.readAsDataURL(f);
            image_count++;
        } else {
            alert('請上傳5張以內');
            break;
        }
    }
    //Clear the input files number display.
    $('#image_file').val('');
}

function handleVideo(evt) {
    reader = new FileReader();
    files = evt.target.files;
    file = files[0];
    reader.onload = function (evt) {
        $('#disp_video').attr("src", evt.target.result);
    }
    reader.readAsDataURL(file);
    image_count++;
}

function handleAudio(evt) {
    reader = new FileReader();
    files = evt.target.files;
    file = files[0];
    reader.onload = function (evt) {
        $('#disp_audio').attr("src", evt.target.result);
    }
    reader.readAsDataURL(file);
    image_count++;
}

function handleSound(evt) {
    reader = new FileReader();
    files = evt.target.files;
    file = files[0];
    reader.onload = function (evt) {
        $('#disp_sound').attr("src", evt.target.result);
    }
    reader.readAsDataURL(file);
    sound_count++;
}

function rmvImg(element, name) {
    $(element).parent().remove();
    image_count--;
}

function myMap() {
    var mapCanvas = document.getElementById("googleMap");
    var myLatLng = new google.maps.LatLng(23.5, 121.120850)
    geocoder = new google.maps.Geocoder();
    markersArray = [];
    var mapOptions = {
        center: myLatLng,
        zoom: 8
    }
    map = new google.maps.Map(mapCanvas, mapOptions);
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    var poi_address = $('#poi_address').val();
    google.maps.event.addListener(map, "click", function (event) {
        placeMarker(event.latLng);

        document.getElementById("latitude").value = event.latLng.lat();
        document.getElementById("longitude").value = event.latLng.lng();

        myLatLng = event.latLng;
        geocoder.geocode({ 'latLng': myLatLng }, function (results, status) {
            if (status === google.maps.GeocoderStatus.OK) {
                map.setCenter(results[0].geometry.location);
                map.setZoom(12);
                // 如果有資料就會回傳
                if (results) {
                    document.getElementById("poi_address").value = results[0].formatted_address;
                }
            }
            // 經緯度資訊錯誤
            else {
                alert("Google 無法辨視此位置 ");
            }
        });

    });
}

function placeMarker(location) {
    deleteOverlays();

    var marker = new google.maps.Marker({
        position: location,
        map: map
    });

    markersArray.push(marker);
}
function deleteOverlays() {
    if (markersArray) {
        for (i in markersArray) {
            markersArray[i].setMap(null);
        }
        markersArray.length = 0;
    }
}
function error(type, str) {
    $(type + '-error').text(str);
    $(type).addClass('err');
}

function clear() {
    $('#title-error').text("");
	$('#subject-error').text("");
    $('#region-error').text("");
    $('#period-error').text("");
    $('#year-error').text("");
    $('#type-error').text("");
	$('#poi_address-error').text("");
	$('#longitude-error').text("");
	$('#poi_description-error').text("");
	$('#format-error').text("");
	$('#media-error').text("");
    $('#title').removeClass('err');
    $('#subject').removeClass('err');
    $('#region').removeClass('err');
    $('#period').removeClass('err');
    $('#year').removeClass('err');
	$('#type').removeClass('err');
	$('#poi_address').removeClass('err');
	$('#longitude').removeClass('err');
	$('#poi_description').removeClass('err');
	$('#format').removeClass('err');
	

}

function check() {
    clear();
    const title = $('#poi_title').val();
	const subject = $("select[name='subject']").val();
	const county= $("select[name='county']").val();
	const district= $("select[name='district']").val();
	const period = $("select[name='period']").val();
	const year = $("select[name='year']").val();
	const type = $("select[name='type']").val();
    const description = $('#poi_description').val();
    const address = $('#poi_address').val();
    const longitude = $('#longitude').val();
	const format = $("select[name='format']").val();
    let ans = true;
    if (title == "") {
        error("#title", '此為必填欄位');
        ans = false;
    }

    if (description == "") {
        error("#description", '此為必填欄位');
        ans = false;
	}
    if (subject == null) {
        error("#subject", '此為必填欄位');
        ans = false;
    } 
    if (county == "" ||district == "") {
        error("#region", '此為必填欄位');
        ans = false;
    } 
    if (period == null) {
        error("#period", '此為必填欄位');
        ans = false;
    }
	if (year == null) {
        error("#year", '此為必填欄位');
        ans = false;
    }
	if (type == null) {
        error("#type", '此為必填欄位');
        ans = false;
    }
	if (address == "") {
        error("#poi_address", '此為必填欄位');
        ans = false;
    }
	if (longitude == "") {
        error("#longitude", '此為必填欄位');
        ans = false;
    }if (format == null) {
        error("#format", '此為必填欄位');
        ans = false;
	}
    return ans;

}
function poi_form() {
	if (check() == true) {
		var urls = "/upload_profile/make_poi/"; //URL Needed
		var poi_title = $('#poi_title').val();
		var subject = $('#subject').val();
		var city = $('.county').val();
		var my_areas = $('.district').val();
		var type = $('#type').val();
		var period = $('#period').val();
		var year = $('#year').val();
		var keyword1 = $('#keyword1').val();
		var keyword2 = $('#keyword2').val();
		var keyword3 = $('#keyword3').val();
		var keyword4 = $('#keyword4').val();
		var poi_address = $('#poi_address').val();
		var latitude = $('#latitude').val();
		var longitude = $('#longitude').val();
		var poi_description = $('#poi_description').val();
		var format = $('#format').val();
		var open = $('#open').val();
		var contributor = $('#contributor').val();
		var media_val = $('.media_val').val();
		var sound_val = $('.sound_val').val();
		var data  = new FormData();
		data.append('poi_title', poi_title);
		data.append('subject', subject);
		data.append('city', city);
		data.append('my_areas',my_areas);
		data.append('type', type);
		data.append('period', period);
		data.append('year', year);
		data.append('keyword1', keyword1);
		data.append('keyword2', keyword2);
		data.append('keyword3', keyword3);
		data.append('keyword4', keyword4);
		data.append('poi_address', poi_address);
		data.append('latitude', latitude);
		data.append('longitude', longitude);
		data.append('poi_description', poi_description);
		data.append('format', format);
		data.append('open', open);
		data.append('contributor', contributor);
		data.append('media_val',md1);
		data.append('sound_val',md2);
		console.log(contributor);
		if( media_val == 1) {
			$("img[name = thumb]").each(function () {
				var dataurl = $(this).attr("src");
				var byteString;
				if (dataurl.split(',')[0].indexOf('base64') >= 0)
					byteString = atob(dataurl.split(',')[1]);
				else
					byteString = unescape(dataurl.split(',')[1]);

				// separate out the mime component
				var mimeString = dataurl.split(',')[0].split(':')[1].split(';')[0];

				// write the bytes of the string to a typed array
				var ia = new Uint8Array(byteString.length);
				for (var i = 0; i < byteString.length; i++) {
					ia[i] = byteString.charCodeAt(i);
				}
				var blob = new Blob([ia], { type: mimeString });
				data.append("img_file", new File([blob], "test.png"));
			});
		}
		//audio
		if(media_val == 2){
			  var audio_file = $('#audio_file').prop('files')[0]; 
			  data.append("audio_file",audio_file);
		}
		
		//video
		if(media_val == 4){
			var video_file = $('#video_file').prop('files')[0]; 
			  data.append("video_file",video_file);
		}
		if(sound_val == 8){
			var sound_file = $('#sound_file').prop('files')[0]; 
			  data.append("sound_file",sound_file);
		}

		$('.alert-danger').empty();
		$('#loading').show();
		$.ajax({
			method: "POST",
			url: urls,
			data: data,
			processData: false,
			contentType: false,
			success: function (data) {
				$('#loading').hide();
				$('.alert-success').show();
				$('.alert-success').append('<p>多媒體上傳成功!</p>');
				 document.getElementById("make_poiform").reset();
			},
			error: function (data) {
				HandleErrUpload(ids);
			},
		});
	}
}
function poi_mpeg(format, ids) {
    var urls = "/upload_profile/make_poi/";
    format = parseInt(format);
    /*ids = parseInt(ids);
    var data = new FormData($('#make_poiform').get(0));
    data.append('foreignkey', ids);

    var media_val = $('.media_val').val();
    if (media_val == 1) {
        //search every uploaded image and append in formdata
        $("img[name = thumb]").each(function () {
            var dataurl = $(this).attr("src");
            var byteString;
            if (dataurl.split(',')[0].indexOf('base64') >= 0)
                byteString = atob(dataurl.split(',')[1]);
            else
                byteString = unescape(dataurl.split(',')[1]);

            // separate out the mime component
            var mimeString = dataurl.split(',')[0].split(':')[1].split(';')[0];

            // write the bytes of the string to a typed array
            var ia = new Uint8Array(byteString.length);
            for (var i = 0; i < byteString.length; i++) {
                ia[i] = byteString.charCodeAt(i);
            }

            var blob = new Blob([ia], { type: mimeString });
            data.append("image_file_modified", blob, $(this).attr("id"));
        });
    }*/
	
	var data  = new FormData();
	var media_val = $('.media_val').val();
	if( media_val == 1) {
		var file = $('#img_file')[0].files[0];
		data.append("img_file", new File([file], 'img_file'));
	}

    $('.alert-danger').empty();
    $('#loading').show();
    $.ajax({
        method: "POST",
        url: urls,
        data: data,
        processData: false,
        contentType: false,
        success: function (data) {
            $('#loading').hide();
            $('.alert-success').show();
            $('.alert-success').append('<p>多媒體上傳成功!</p>');
			
        },
        error: function (data) {
            HandleErrUpload(ids);
        },
    });
}

function poi_sound(format, ids) {
    var urls = "/upload_profile/make_poi/";
    format = parseInt(format);
    ids = parseInt(ids);
    var data = new FormData($('#make_poiform').get(0));
    data.append('foreignkey', ids);
    $('.alert-danger').empty();
    $('#loading').show();
    $.ajax({
        method: "POST",
        url: urls,
        data: data,
        processData: false,
        contentType: false,
        success: function (data) {
            $('#loading').hide();
            $('.alert-success').show();
            $('.alert-success').append('<p>景點上傳成功!</p>');
			window.location = "/upload_profile/make_poi/";
        },
        error: function (data) {
            console.log(data);
        },
    });
}
function SubmitForm(event) {
    event.preventDefault();
    poi_form();
}
$('#clear').on('click', function () {
    image_count = 0;
});

$(document).ajaxSend(function(event, xhr, settings) {
    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    function sameOrigin(url) {
        // url could be relative or scheme relative or absolute
        var host = document.location.host; // host + port
        var protocol = document.location.protocol;
        var sr_origin = '//' + host;
        var origin = protocol + sr_origin;
        // Allow absolute or scheme relative URLs to same origin
        return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
            (url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') ||
            // or any other URL that isn't scheme relative or absolute i.e relative.
            !(/^(\/\/|http:|https:).*/.test(url));
    }
    function safeMethod(method) {
        return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
    }
 
    if (!safeMethod(settings.type) && sameOrigin(settings.url)) {
        xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
    }
})