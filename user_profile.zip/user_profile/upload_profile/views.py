from django.shortcuts import render
from .models import SOI,AOI,LOI,MAP,diffMAP,Media,POI,POI_content,Beacon
from django.views.decorators.csrf import csrf_exempt
import json
from django.http import HttpResponse
from django.core import serializers
from django.http import JsonResponse
from django.contrib import auth
from django.http import HttpResponseRedirect
from django.contrib.auth.models import User

#def的名子不能跟model一樣 不然會有問題



@csrf_exempt 
def login(request):
    if request.method == 'POST':
        user = request.POST.get('username')
        passwd = request.POST.get('password')
        #if request.user.is_authenticated: 登錄中
            #print("wp")
            
            #if key in request.session:
            
        try:
            passwd_db = User.objects.get(username=user).password
        except:
            data={'0':False,'1':"Please input the correct User name"}
            return HttpResponse(json.dumps(data),content_type="application/json")
        if User.objects.get(username=user).check_password(passwd):
            request.session['username'] = user
            request.session.set_expiry(600)#s
            data={'0':True,'1':"Login successfully"}
            return HttpResponse(json.dumps(data),content_type="application/json")
            #return HttpResponse(True,"Login successfully") #導向首頁的html?
        else:
            data={'0':False,'1':"Please input the correct password"}
            return HttpResponse(json.dumps(data),content_type="application/json")
            #return HttpResponse(False,"Please input the correct password")
        
    return render(request, 'upload_profile/login.html', locals())
    
@csrf_exempt 
def logout(request):
    auth.logout(request)
    data={'0':True,'1':"Logout successfully"}
    return HttpResponse(json.dumps(data),content_type="application/json")
    #return HttpResponse(True,"Logout successfully")#導向首頁的html?


@csrf_exempt 
def sign_up(request):
    if request.method == 'POST':
        user = request.POST.get('name')
        email = request.POST.get('email')
        passwd = request.POST.get('password')
        gender=request.POST.get('gender')
        role = request.POST.get('role')

        print(user)
        print(email)
        print(passwd)
        print(gender)
        print(role)
        
        #if request.user.is_authenticated: 登錄中
            #print("wp")
            
            #if key in request.session:
            
        try:
            passwd_db = User.objects.get(username=user).password
            data={'0':False,'1':"The account name is already being use"}
            return HttpResponse(json.dumps(data),content_type="application/json")
            #return HttpResponse(False,"The account name is already being use")
        except:
                temp = User.objects.create_user(user,email,passwd)
                #temp.first_name = "victor"
                #temp.last_name = "chen"
                temp.is_staff = "False"
                temp.save()
            
                request.session['username'] = user
                request.session.set_expiry(600)#s
                
                data={'0':True,'1':"Login successfully"}
                return HttpResponse(json.dumps(data),content_type="application/json")
                #return HttpResponse(True,"Login successfully") #導向首頁的html?

    return render(request, 'upload_profile/sign_up.html', locals())

@csrf_exempt 
def change(request):
    #看type及id，temp=type.objects.get(id=) 舊欄位=新欄位 temp.save()
    return render(request, 'upload_profile/???.html',locals())


@csrf_exempt 
def Poi(request):
    if request.method == "POST":
        
        標題 = request.POST.get('poi_title') 
        主題 = request.POST.get('subject') 
        地區1 = request.POST.get('city')
        地區2 = request.POST.get('my_areas')
        類型 = request.POST.get('type') 
        時期 = request.POST.get('period') 
        年份 = request.POST.get('year') 
        關鍵字_1 = request.POST.get('keyword1') 
        關鍵字_2 = request.POST.get('keyword2') 
        關鍵字_3 = request.POST.get('keyword3') 
        關鍵字_4 = request.POST.get('keyword4') 
        地址 = request.POST.get('poi_address') 
        經度 = request.POST.get('longitude') 
        緯度 = request.POST.get('latitude') 
        
        描述 = request.POST.get('poi_description') 
        範疇 = request.POST.get('format')
        

        
        try:
            貢獻者 = request.session["username"]
        except:
            貢獻者 = ""

        公開 = request.POST.get('open')         
        圖片url = request.FILES.getlist('img_file')
        
        media_val = request.POST.get('media_val') 
        sound_val = request.POST.get('sound_val')      

        
        
        導覽url = request.FILES.get('sound_file')
        聲音url = request.FILES.get('audio_file')
        影片url = request.FILES.get('video_file')

        
        n = int(media_val) + int(sound_val)
        
        if 主題=="null" :
            主題=''
        if 地區1=="null" :
            地區1=''
        if 地區2=="null" :
            地區2=''
        if 類型=="null" :
            類型=''
        if 時期=="null" :
            時期=''
        if 年份=="null" :
            年份=''
        if 範疇=="null" :
            範疇=''
        
        改動 = request.POST.get('change') 
        ID = request.POST.get('change_id')
        if 改動 == 1:
            POI.objects.filter(id=ID).delete()
            Media.objects.filter(to_id=ID).delete()
            
        poi = POI(
           poi_title = 標題,
           subject = 主題,
           city = 地區1,
           my_areas = 地區2,
           TYPE = 類型,
           period = 時期,
           year = 年份,
           keyword1 = 關鍵字_1 ,
           keyword2 = 關鍵字_2 ,
           keyword3 = 關鍵字_3 ,
           keyword4 = 關鍵字_4 ,
           poi_address = 地址 ,
           longitude = 經度 ,
           latitude = 緯度 ,
       
           poi_description = 描述 ,
           FORMAT = 範疇 ,
           contributor = 貢獻者 ,
           OPEN = 公開 ,
           media_type = str(n)
        )
        poi.save()
        list_poi=POI.objects.order_by('-id')[0:1]
       
        if n == 1:
           for i in range(len(圖片url)):
               media = Media(name = 標題,TYPE = 'image',url = 圖片url[i],to_id = list_poi[0].id)
               media.save()
        
        elif n == 5:
            for i in range(len(圖片url)):
                media = Media(name = 標題,TYPE = 'image',url = 圖片url[i],to_id = list_poi[0].id)
                media.save()
               
            media = Media(name = 標題,TYPE = 'sound',url = 導覽url,to_id = list_poi[0].id)
            media.save()
            
        elif n == 2:
            media = Media(name = 標題,TYPE = 'video',url = 影片url,to_id = list_poi[0].id)
            media.save()
            
        elif n == 6:
            media = Media(name = 標題,TYPE = 'video',url = 影片url,to_id = list_poi[0].id)
            media.save()

            media = Media(name = 標題,TYPE = 'sound',url = 導覽url,to_id = list_poi[0].id)
            media.save()
            
        elif n == 3:
            media = Media(name = 標題,TYPE = 'audio',url = 聲音url,to_id = list_poi[0].id)
            media.save()
            
        elif n == 7:
            media = Media(name = 標題,TYPE = 'audio',url = 聲音url,to_id = list_poi[0].id)
            media.save()
            
            media = Media(name = 標題,TYPE = 'sound',url = 導覽url,to_id = list_poi[0].id)
            media.save()
            
        elif n == 8:
            media = Media(name = 標題,TYPE = 'sound',url = 導覽url,to_id = list_poi[0].id)
            media.save()
            
            
        
        return render(request, 'upload_profile/make_poi.html', locals())
    
    return render(request, 'upload_profile/make_poi.html', locals())

@csrf_exempt 
def Map(request):
    if request.method == "POST":
        標題 = request.POST.get('title')
        描述 = request.POST.get('description') 
        樓層 = request.POST.get('floor') 
        比例 = request.POST.get('scale')
        url = request.FILES.get('map') 
        group = request.POST.get('group')
        try:
            貢獻者 = request.session["username"]
        except:
            貢獻者 = ""
        
        counter=request.POST.get('counter')
        beacon_counter=request.POST.get('beacon_counter')
        poi_counter=request.POST.get('poi_counter')
        
        改動 = request.POST.get('change') 
        ID = request.POST.get('change_id')
        if 改動 == 1:
            AOI.objects.filter(id=ID).delete()
            mapid=MAP.objects.get(to_id=ID).id
            
            MAP.objects.get(to_id=ID).delete()
            Media.objects.filter(to_id=mapid).delete()
            Beacon.objects.filter(MAP_ID=mapid).delete()
            POI_content.objects.filter(to_id=ID).delete()
            df=diffMAP.objects.filter(MAP_ID=mapid)
            for ddd in df:    
                dfid=ddd.id
                Media.objects.get(to_id=dfid).delete()
            diffMAP.objects.filter(MAP_ID=mapid).delete()
            
        Aoi = AOI(name=標題,intro=描述,SOI_ID="-1",X="-1",Y="-1",floor=樓層,contributor=貢獻者)
        Aoi.save()
        list_aoi=AOI.objects.order_by('-id')[0:1]
        
        
        Map = MAP(map_title=標題, map_description=描述,floor=樓層,scale=比例,Beacon_num=beacon_counter,TYPE="AOI",to_id=list_aoi[0].id)
        Map.save()
        list_map=MAP.objects.order_by('-id')[0:1]
        
        temp = AOI.objects.get(id=list_aoi[0].id)
        temp.AOI_group = list_aoi[0].id
        temp.MAP_ID = list_map[0].id
        temp.save()

            
        media = Media(
                name = 標題,
                TYPE = 'MAP',
                url = url,
                to_id = list_map[0].id,
                )
        media.save()
            
        if int(beacon_counter) > 0:
            beacons = request.POST.get('beacons')
            t = json.loads(beacons)
            for i in t:
                beacon=Beacon(name=標題,Beacon_X=i["x"],Beacon_Y=i["y"],MAP_ID=list_map[0].id)
                beacon.save()
             #rssi Major minor
             
        if int(poi_counter) > 0:
            pois = request.POST.get('pois')
            t = json.loads(pois)
            for i in t :
                response = POI.objects.get(poi_title=i["name"])
                poi_content = POI_content(X=i["x"],Y=i["y"],TYPE="AOI",to_id=list_aoi[0].id,POI_ID=response.id,order="-1")
                poi_content.save()
                temp = AOI.objects.get(id=list_aoi[0].id)
                temp.longitude = response.longitude
                temp.latitude = response.latitude
                temp.save()
        
        
        
        
        if int(counter) > 0:
            diffmaps = request.POST.get('diffmaps')
            t = json.loads(diffmaps)
            ct = 1
            for i in t:
                url = request.FILES.get('map'+ str(ct))
                diffmap = diffMAP(name = 標題,MAP_ID =  list_map[0].id,scale = i["scale"])
                diffmap.save()
                
                list_diff=diffMAP.objects.order_by('-id')[0:1]
                
                media = Media(name = 標題,TYPE = 'diffMAP',url = url,to_id = list_diff[0].id,)
                media.save()
                ct+=1
        
        if group != "null":
            temp = AOI.objects.get(id=list_aoi[0].id)
            temp.AOI_group = group
            temp.save()
        
        
        return render(request, 'upload_profile/make_aoi.html', locals())


    return render(request, 'upload_profile/make_aoi.html', locals())
@csrf_exempt 
def Loi(request):
    if request.method == "POST":
        標題 = request.POST.get('title')
        描述 = request.POST.get('description') 
        樓層 = request.POST.get('floor') 
        比例 = request.POST.get('scale')
        url = request.FILES.get('map') 
        group = request.POST.get('group')
        try:
            貢獻者 = request.session["username"]
        except:
            貢獻者 = ""
        
        
        counter=request.POST.get('counter')
        beacon_counter=request.POST.get('beacon_counter')
        poi_counter=request.POST.get('poi_counter')
        
        改動 = request.POST.get('change') 
        ID = request.POST.get('change_id')
        if 改動 == 1:
            SOI.objects.filter(id=ID).delete()
            mapid=MAP.objects.get(to_id=ID).id
            
            MAP.objects.get(to_id=ID).delete()
            Media.objects.filter(to_id=mapid).delete()
            Beacon.objects.filter(MAP_ID=mapid).delete()
            POI_content.objects.filter(to_id=ID).delete()
            df=diffMAP.objects.filter(MAP_ID=mapid)
            for ddd in df:    
                dfid=ddd.id
                Media.objects.get(to_id=dfid).delete()
            diffMAP.objects.filter(MAP_ID=mapid).delete()
        
        Loi = LOI(name=標題,intro=描述,SOI_ID="-1",X="-1",Y="-1",floor=樓層,contributor=貢獻者)
        Loi.save()
        list_loi=LOI.objects.order_by('-id')[0:1]
        
        
        Map = MAP(map_title=標題, map_description=描述,floor=樓層,scale=比例,Beacon_num=beacon_counter,TYPE="LOI",to_id=list_loi[0].id)
        Map.save()
        list_map=MAP.objects.order_by('-id')[0:1]
        
        temp = LOI.objects.get(id=list_loi[0].id)
        temp.LOI_group = list_loi[0].id
        temp.MAP_ID = list_map[0].id
        temp.save()

            
        media = Media(
                name = 標題,
                TYPE = 'MAP',
                url = url,
                to_id = list_map[0].id,
                )
        media.save()
            
        if int(beacon_counter) > 0:
            beacons = request.POST.get('beacons')
            t = json.loads(beacons)
            for i in t:
                beacon=Beacon(name=標題,Beacon_X=i["x"],Beacon_Y=i["y"],MAP_ID=list_map[0].id)
                beacon.save()
             #rssi Major minor
             
        if int(poi_counter) > 0:
            pois = request.POST.get('pois')
            t = json.loads(pois)
            for i in t :
                response = POI.objects.get(poi_title=i["name"])
                poi_content = POI_content(X=i["x"],Y=i["y"],TYPE="LOI",to_id=list_loi[0].id,POI_ID=response.id,order=i["order"])
                poi_content.save()
                temp = LOI.objects.get(id=list_loi[0].id)
                temp.longitude = response.longitude
                temp.latitude = response.latitude
                temp.save()
        
        
        
        
        if int(counter) > 0:
            diffmaps = request.POST.get('diffmaps')
            t = json.loads(diffmaps)
            ct = 1
            for i in t:
                url = request.FILES.get('map'+ str(ct))
                diffmap = diffMAP(name = 標題,MAP_ID =  list_map[0].id,scale = i["scale"])
                diffmap.save()
                
                list_diff=diffMAP.objects.order_by('-id')[0:1]
                
                media = Media(name = 標題,TYPE = 'diffMAP',url = url,to_id = list_diff[0].id,)
                media.save()
                ct+=1
                
        if group != "-1":
            temp = LOI.objects.get(id=list_loi[0].id)
            temp.LOI_group = group
            temp.save()
            
            
            
        return render(request, 'upload_profile/make_loi.html', locals())
    
    return render(request, 'upload_profile/make_loi.html', locals())

@csrf_exempt 
def Soi(request):
    if request.method == "POST":
        標題 = request.POST.get('title')
        描述 = request.POST.get('description') 
        樓層 = request.POST.get('floor') 
        比例 = request.POST.get('scale')
        url = request.FILES.get('map') 
        
        counter=request.POST.get('counter')
        beacon_counter=request.POST.get('beacon_counter')
        poi_counter=request.POST.get('poi_counter')
        aoi_counter=request.POST.get('aoi_counter')
        loi_counter=request.POST.get('loi_counter')
        try:
            貢獻者 = request.session["username"]
        except:
            貢獻者 = ""
        
        
        改動 = request.POST.get('change') 
        ID = request.POST.get('change_id')
        if 改動 == 1:
            SOI.objects.filter(id=ID).delete()
            mapid=MAP.objects.get(to_id=ID).id
            
            MAP.objects.get(to_id=ID).delete()
            Media.objects.filter(to_id=mapid).delete()
            Beacon.objects.filter(MAP_ID=mapid).delete()
            POI_content.objects.filter(to_id=ID).delete()
            df=diffMAP.objects.filter(MAP_ID=mapid)
            for ddd in df:    
                dfid=ddd.id
                Media.objects.get(to_id=dfid).delete()
            diffMAP.objects.filter(MAP_ID=mapid).delete()
            
            aoi=AOI.objects.filter(SOI_ID=ID)
            for ddd in aoi:
                ddd.SOI_ID="-1"
                ddd.save()
            
            loi=LOI.objects.filter(SOI_ID=ID)
            for ddd in loi:
                ddd.SOI_ID="-1"
                ddd.save()
            
        
        Soi = SOI(name=標題,intro=描述,contributor=貢獻者)
        Soi.save()
        list_soi=SOI.objects.order_by('-id')[0:1]
        
        
        Map = MAP(map_title=標題, map_description=描述,floor=樓層,scale=比例,Beacon_num=beacon_counter,TYPE="SOI",to_id=list_soi[0].id)
        Map.save()
        list_map=MAP.objects.order_by('-id')[0:1]
        
        temp = SOI.objects.get(id=list_soi[0].id)
        temp.MAP_ID = list_map[0].id
        temp.save()

            
        media = Media(
                name = 標題,
                TYPE = 'MAP',
                url = url,
                to_id = list_map[0].id,
                )
        media.save()
            
        if int(beacon_counter) > 0:
            beacons = request.POST.get('beacons')
            t = json.loads(beacons)
            for i in t:
                beacon=Beacon(name=標題,Beacon_X=i["x"],Beacon_Y=i["y"],MAP_ID=list_map[0].id)
                beacon.save()
             #rssi Major minor
             
        if int(poi_counter) > 0:
            pois = request.POST.get('pois')
            t = json.loads(pois)
            for i in t :
                response = POI.objects.get(poi_title=i["name"])
                poi_content = POI_content(X=i["x"],Y=i["y"],TYPE="SOI",to_id=list_soi[0].id,POI_ID=response.id,order="-1")
                poi_content.save()
                temp = SOI.objects.get(id=list_soi[0].id)
                temp.longitude = response.longitude
                temp.latitude = response.latitude
                temp.save()
        
        
        if int(aoi_counter) > 0:
            aois = request.POST.get('aois')
            t = json.loads(aois)
            for i in t :
                response = AOI.objects.get(name=i["name"])
                response.X = i["x"]
                response.Y = i["y"]
                response.save()
                
                dd = response.AOI_group
                response2 = AOI.objects.filter(AOI_group=dd)
                for ddd in response2:    
                    ddd.SOI_ID = list_soi[0].id
                    ddd.save()
                
                temp = SOI.objects.get(id=list_soi[0].id)
                temp.longitude = response.longitude
                temp.latitude = response.latitude
                temp.save()
        
        if int(loi_counter) > 0:
            lois = request.POST.get('lois')
            t = json.loads(lois)
            for i in t :
                response = LOI.objects.get(name=i["name"])
                response.X = i["x"]
                response.Y = i["y"]
                response.save()
                
                dd = response.LOI_group
                response2 = LOI.objects.filter(LOI_group=dd)
                for ddd in response2:    
                    ddd.SOI_ID = list_soi[0].id
                    ddd.save()
                
                
                temp = SOI.objects.get(id=list_soi[0].id)
                temp.longitude = response.longitude
                temp.latitude = response.latitude
                temp.save()
                
                
        if int(counter) > 0:
            diffmaps = request.POST.get('diffmaps')
            t = json.loads(diffmaps)
            ct = 1
            for i in t:
                url = request.FILES.get('map'+ str(ct))
                diffmap = diffMAP(name = 標題,MAP_ID =  list_map[0].id,scale = i["scale"])
                diffmap.save()
                
                list_diff=diffMAP.objects.order_by('-id')[0:1]
                
                media = Media(name = 標題,TYPE = 'diffMAP',url = url,to_id = list_diff[0].id,)
                media.save()
                ct+=1
                
                
        return render(request, 'upload_profile/make_soi.html', locals())
    
    return render(request, 'upload_profile/make_soi.html', locals())
def Demo(request):
    return render(request, 'upload_profile/demo.html', locals())
    
def services(request):
    return render(request, 'upload_profile/services.html', locals())
    
def index(request):
    return render(request, 'upload_profile/index.html', locals())
def info(request):
    return render(request, 'upload_profile/info.html', locals())
