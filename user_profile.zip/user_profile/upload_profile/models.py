from django.db import models

from collections import namedtuple

from django.db import connection

class SOI(models.Model):
    class Meta:
        db_table = 'proj_SOI'
    
    name = models.CharField(max_length=300,null=True,blank=True)
    intro = models.CharField(max_length=300,null=True,blank=True)
    MAP_ID = models.CharField(max_length=300,null=True,blank=True)
    longitude = models.CharField(max_length=300,null=True,blank=True)
    latitude = models.CharField(max_length=300,null=True,blank=True)
    contributor = models.CharField(max_length=300,null=True,blank=True)

    def __str__(self):
        return self.name
    
class AOI(models.Model):
    class Meta:
        db_table = 'proj_AOI'
    
    name = models.CharField(max_length=300,null=True,blank=True)
    intro = models.CharField(max_length=300,null=True,blank=True)
    MAP_ID = models.CharField(max_length=300,null=True,blank=True)
    SOI_ID = models.CharField(max_length=300,null=True,blank=True) #not in SOI:-1
    X = models.CharField(max_length=300,null=True,blank=True)
    Y = models.CharField(max_length=300,null=True,blank=True)
    floor = models.CharField(max_length=300,null=True,blank=True)
    AOI_group = models.CharField(max_length=300,null=True,blank=True) #帶頭的=id=同組的
    longitude = models.CharField(max_length=300,null=True,blank=True)
    latitude = models.CharField(max_length=300,null=True,blank=True)
    contributor = models.CharField(max_length=300,null=True,blank=True)

    def __str__(self):
        return self.name

class LOI(models.Model):
    class Meta:
        db_table = 'proj_LOI'
    
    name = models.CharField(max_length=300,null=True,blank=True)
    intro = models.CharField(max_length=300,null=True,blank=True)
    MAP_ID = models.CharField(max_length=300,null=True,blank=True)
    SOI_ID = models.CharField(max_length=300,null=True,blank=True) #not in SOI:-1
    X = models.CharField(max_length=300,null=True,blank=True)
    Y = models.CharField(max_length=300,null=True,blank=True)
    floor = models.CharField(max_length=300,null=True,blank=True)
    LOI_group = models.CharField(max_length=300,null=True,blank=True) #帶頭的=id=同組的
    longitude = models.CharField(max_length=300,null=True,blank=True)
    latitude = models.CharField(max_length=300,null=True,blank=True)
    contributor = models.CharField(max_length=300,null=True,blank=True)
    
    def __str__(self):
        return self.name

class MAP(models.Model):
    class Meta:
        db_table = 'proj_MAP'
    
    map_title = models.CharField(max_length=300,null=True,blank=True)
    map_description = models.CharField(max_length=300,null=True,blank=True)
    floor = models.CharField(max_length=300,null=True,blank=True)
    
    TYPE = models.CharField(max_length=300,null=True,blank=True) #AOI|SOI|LOI
    to_id = models.CharField(max_length=300,null=True,blank=True)
    
    scale = models.CharField(max_length=300,null=True,blank=True)
    Beacon_num = models.CharField(max_length=300,null=True,blank=True)
    
    
    def __str__(self):
        return self.map_title

class diffMAP(models.Model):
    class Meta:
        db_table = 'proj_diffMAP'
    
    name = models.CharField(max_length=300,null=True,blank=True)
    scale = models.CharField(max_length=300,null=True,blank=True)
    MAP_ID = models.CharField(max_length=300,null=True,blank=True)
    
    def __str__(self):
        return self.name
    
class Media(models.Model):
    class Meta:
        db_table = 'proj_Media'
    
    name = models.CharField(max_length=300,null=True,blank=True)
    TYPE = models.CharField(max_length=300,null=True,blank=True) #MAP|diffMAP|poi_pic|sound|image|video|audio|
    to_id = models.CharField(max_length=300,null=True,blank=True)#to map|diffmap|poi
    url = models.FileField(upload_to='',null=True)
    
    def __str__(self):
        return self.name
    

class POI(models.Model):
    class Meta:
        db_table = 'proj_POI'
                
    poi_title = models.CharField(max_length=300,null=True,blank=True)
    subject = models.CharField(max_length=300,null=True,blank=True)
    city = models.CharField(max_length=300,null=True,blank=True)
    my_areas = models.CharField(max_length=300,null=True,blank=True)
    TYPE = models.CharField(max_length=300,null=True,blank=True)
    period = models.CharField(max_length=300,null=True,blank=True)
    year = models.CharField(max_length=300,null=True,blank=True)
    keyword1 = models.CharField(max_length=300,null=True,blank=True)
    keyword2 = models.CharField(max_length=300,null=True,blank=True)
    keyword3 = models.CharField(max_length=300,null=True,blank=True)
    keyword4 = models.CharField(max_length=300,null=True,blank=True)
    poi_address = models.CharField(max_length=300,null=True,blank=True)
    longitude = models.CharField(max_length=300,null=True,blank=True)
    latitude = models.CharField(max_length=300,null=True,blank=True)
    
    poi_description = models.CharField(max_length=300,null=True,blank=True)
    FORMAT = models.CharField(max_length=300,null=True,blank=True)
    contributor = models.CharField(max_length=300,null=True,blank=True)
    OPEN = models.CharField(max_length=300,null=True,blank=True)
    media_type = models.CharField(max_length=300,null=True,blank=True)        
    def __str__(self):
        return self.poi_title
    
class POI_content(models.Model):
    class Meta:
        db_table = 'proj_POI_content'
    
    X = models.CharField(max_length=300,null=True,blank=True)
    Y = models.CharField(max_length=300,null=True,blank=True)
    
    TYPE = models.CharField(max_length=300,null=True,blank=True)#AOI|SOI|LOI
    to_id = models.CharField(max_length=300,null=True,blank=True)
    
    POI_ID = models.CharField(max_length=300,null=True,blank=True)
    order = models.CharField(max_length=300,null=True,blank=True) #AOI|SOI=-1
    
    def __str__(self):
        return self.POI_ID

class Beacon(models.Model):
    class Meta:
        db_table = 'proj_Beacon'
    
    name = models.CharField(max_length=300,null=True,blank=True)
    MAP_ID = models.CharField(max_length=300,null=True,blank=True)
    Beacon_X = models.CharField(max_length=300,null=True,blank=True)
    Beacon_Y = models.CharField(max_length=300,null=True,blank=True)
    rssi = models.CharField(max_length=300,null=True,blank=True)
    Major = models.CharField(max_length=300,null=True,blank=True)
    Minor = models.CharField(max_length=300,null=True,blank=True)

    
    def __str__(self):
        return self.MAP_ID




#-------
#v search API v
#-------
def namedtuplefetchall(cursor):
    # Return all rows from a cursor as a namedtuple
    desc = cursor.description
    nt_result = namedtuple('Result', [col[0] for col in desc])
    return [nt_result(*row) for row in cursor.fetchall()]
    
    
def fcn_sql_query_soi(**kwargs):
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM [MOE3].[dbo].[proj_SOI]")
        c_result = namedtuplefetchall(cursor)

    result =[]
    for r in c_result:
       #first find poi in soi
        with connection.cursor() as cursor:
            cursor.execute(sql_poi_str_top1() + " and [MOE3].[dbo].[proj_POI_content].[TYPE] = 'SOI' and [MOE3].[dbo].[proj_POI_content].to_id = " + str(r.id))
            first_poi =  namedtuplefetchall(cursor)
    
        #then find poi in aoi
        if(len(first_poi) < 1):
            with connection.cursor() as cursor:
                cursor.execute("SELECT TOP 1 * FROM [MOE3].[dbo].[proj_AOI] WHERE SOI_ID = " + str(r.id))
                first_aoi = namedtuplefetchall(cursor)
            with connection.cursor() as cursor:
                cursor.execute(sql_poi_str_top1() + " and [MOE3].[dbo].[proj_POI_content].[TYPE] = 'AOI' and [MOE3].[dbo].[proj_POI_content].to_id = " + str(first_aoi[0].id))
                first_poi =  namedtuplefetchall(cursor)
            
        #then find poi in loi
        if(len(first_poi) < 1):
            with connection.cursor() as cursor:
                cursor.execute("SELECT TOP 1 * FROM [MOE3].[dbo].[proj_LOI] WHERE SOI_ID = " + str(r.id))
                first_loi = namedtuplefetchall(cursor)
            with connection.cursor() as cursor:
                cursor.execute(sql_poi_str_top1() + " and [MOE3].[dbo].[proj_POI_content].[TYPE] = 'LOI' and [MOE3].[dbo].[proj_POI_content].to_id = " + str(first_loi[0].id))
                first_poi =  namedtuplefetchall(cursor)
                
        if(len(first_poi) > 0):
            result.append(
            {
                's_id': r.id,
                'name' : r.name,
                'description' : r.intro,
                'm_id' : r.MAP_ID,
                'lat' : first_poi[0].latitude,
                'lng' : first_poi[0].longitude,
                'contributor' : r.contributor,
             },)
        
    return result
    
def sql_poi_str_top1():
    #select top 1 poi's lat & lng from poi and poi_content
    return "SELECT TOP 1 [MOE3].[dbo].[proj_POI].poi_title, [MOE3].[dbo].[proj_POI].longitude, [MOE3].[dbo].[proj_POI].latitude FROM MOE3.dbo.proj_POI, [MOE3].[dbo].[proj_POI_content] WHERE MOE3.dbo.proj_POI.id = [MOE3].[dbo].[proj_POI_content].POI_ID"

def fcn_sql_query_aoi_GoogleMap():
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM [MOE3].[dbo].[proj_AOI] WHERE SOI_ID = -1 and id=AOI_group") # 
        c_result = namedtuplefetchall(cursor)
        
    result =[]
    for r in c_result:
        with connection.cursor() as cursor:
            cursor.execute(sql_poi_str_top1() + " and [MOE3].[dbo].[proj_POI_content].[TYPE] = 'AOI' and [MOE3].[dbo].[proj_POI_content].to_id = " + str(r.id))
            first_poi =  namedtuplefetchall(cursor)
        if(len(first_poi) > 0):
            result.append(
            {
                'a_id': r.id,
                'name' : r.name,
                'description' : r.intro,
                'm_id' : r.MAP_ID,
                'lat' : first_poi[0].latitude,
                'lng' : first_poi[0].longitude,
                'contributor' : r.contributor,
             },)
        
    return result
    
def fcn_sql_query_loi_GoogleMap():
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM [MOE3].[dbo].[proj_LOI] WHERE SOI_ID = -1 and id=LOI_group") # WHERE SOI_ID = -1
        c_result = namedtuplefetchall(cursor)
        
    result =[]
    for r in c_result:
        with connection.cursor() as cursor:
            cursor.execute(sql_poi_str_top1() + " and [MOE3].[dbo].[proj_POI_content].[TYPE] = 'LOI' and [MOE3].[dbo].[proj_POI_content].to_id = " + str(r.id))
            first_poi =  namedtuplefetchall(cursor)
        if(len(first_poi) > 0):
            result.append(
            {
                'l_id': r.id,
                'name' : r.name,
                'description' : r.intro,
                'm_id' : r.MAP_ID,
                'lat' : first_poi[0].latitude,
                'lng' : first_poi[0].longitude,
                'contributor' : r.contributor,
             },)
        
    return result

def fcn_sql_query_poi(**kwargs):
    type = kwargs.get('type')
    id = kwargs.get('id')
    with connection.cursor() as cursor:
        cursor.execute(sql_poi_str()+" and  [MOE3].[dbo].[proj_POI_content].[TYPE] = '"+type+"'" + " and [MOE3].[dbo].[proj_POI_content].to_id = " + id + " ORDER BY [MOE3].[dbo].[proj_POI_content].[order]")
        c_result = namedtuplefetchall(cursor)
    result =[]
    for r in c_result:
        result.append(
        {
            'p_id': r.id,
            'name' : r.poi_title,
            'type' : r.TYPE,
            'lng' : r.longitude,
            'lat' : r.latitude,
            'description' : r.poi_description,
            'contributor' : r.contributor,
            'x' : r.X,
            'y' : r.Y,
            'order' : r.order,
            'media_type' : r.media_type
         },)
    return result
    
def sql_poi_str():
    #select from poi and poi_content
    return "SELECT [MOE3].[dbo].[proj_POI].id, [MOE3].[dbo].[proj_POI].poi_title, [MOE3].[dbo].[proj_POI].[TYPE], [MOE3].[dbo].[proj_POI].media_type, [MOE3].[dbo].[proj_POI].longitude, [MOE3].[dbo].[proj_POI].latitude, [MOE3].[dbo].[proj_POI].poi_description, [MOE3].[dbo].[proj_POI].contributor, [MOE3].[dbo].[proj_POI_content].POI_ID, [MOE3].[dbo].[proj_POI_content].X, [MOE3].[dbo].[proj_POI_content].Y, [MOE3].[dbo].[proj_POI_content].to_id, [MOE3].[dbo].[proj_POI_content].[order] FROM MOE3.dbo.proj_POI, [MOE3].[dbo].[proj_POI_content] WHERE MOE3.dbo.proj_POI.id = [MOE3].[dbo].[proj_POI_content].POI_ID"

    
def fcn_sql_query_map(**kwargs):
    type = kwargs.get('type')
    id = kwargs.get('id')
    with connection.cursor() as cursor:
        cursor.execute(sql_map_img_str()+" and [MOE3].[dbo].[proj_MAP].[TYPE] = '"+type+"'" + " and [MOE3].[dbo].[proj_MAP].[to_id] = " + id)
        c_result = namedtuplefetchall(cursor)
    result =[]
    for r in c_result:
        result.append(
        {
            'm_id': r.id,
            'name' : r.map_title,
            'floor' : r.floor,
            'scale' : r.scale,
            'beacon_num' : r.Beacon_num,
            'description' : r.map_description,
            'url' : r.url,
         },)
    return result
    
def sql_map_img_str():
    #select from MAP and Media
    return "SELECT [MOE3].[dbo].[proj_MAP].[id], [map_title], [map_description], [floor],[scale],[Beacon_num], [MOE3].[dbo].[proj_Media].url FROM [MOE3].[dbo].[proj_MAP], [MOE3].[dbo].[proj_Media] WHERE [MOE3].[dbo].[proj_Media].[TYPE] = 'MAP' and [MOE3].[dbo].[proj_MAP].[id] = [MOE3].[dbo].[proj_Media].to_id"
    
def fcn_sql_query_diffmap(**kwargs):
    mid = kwargs.get('id')
    with connection.cursor() as cursor:
        cursor.execute(sql_diffmap_img_str()+" and [MOE3].[dbo].[proj_diffMAP].[MAP_ID] = " + mid + " ORDER BY [MOE3].[dbo].[proj_diffMAP].[scale]")
        c_result = namedtuplefetchall(cursor)
    result =[]
    for r in c_result:
        result.append(
        {
            'scale': r.scale,
            'url' : r.url,
         },)
    return result

def sql_diffmap_img_str():
    #select from diffMAP and Media
    return "SELECT [MOE3].[dbo].[proj_diffMAP].[scale], [MOE3].[dbo].[proj_Media].url FROM [MOE3].[dbo].[proj_diffMAP], [MOE3].[dbo].[proj_Media] WHERE [MOE3].[dbo].[proj_Media].[TYPE] = 'diffMAP' and [MOE3].[dbo].[proj_diffMAP].[id] = [MOE3].[dbo].[proj_Media].to_id"
 

"""
def fun_raw_sql_query_aoi_summary(**kwargs):
    mid = kwargs.get('id')
    if mid:
        result = AOILOI_summary.objects.raw('SELECT * FROM dbo.proj_AOILOI_summary WHERE MAP_ID = %s', [mid])
    else:
        result = AOILOI_summary.objects.raw('SELECT * FROM dbo.proj_AOILOI_summary')
    return result

def fun_raw_sql_query_poi(**kwargs):
    mid = kwargs.get('id')
    if mid:
        result = POI.objects.raw('SELECT * FROM dbo.proj_POI WHERE MAP_ID = %s', [mid])
    else:
        result = POI.objects.raw('SELECT * FROM dbo.proj_POI')
    return result

def fun_sql_cursor_POI_in_AOI(**kwargs):
    aid = kwargs.get('id')
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM dbo.proj_AOILOI_content WHERE AOILOI_ID = %s", [aid])
        result1 = namedtuplefetchall(cursor)
        
        result =[]
        for r in result1:
            poi = POI.objects.filter(id=r.POI_ID)
          
            for i in poi:
                result.append(
                    {
                        'POI_ID': r.POI_ID,
                        '順序' : r.順序,
                        '名稱' : i.名稱,
                        '描述' : i.描述,
                        '區域' : i.區域,
                        'SOI_ID' : i.SOI_ID,
                        'MAP_ID' : i.MAP_ID,
                        'POI_X' : i.POI_X,
                        'POI_Y' : i.POI_Y,
                        '樓層' : i.樓層,
                    },)
    return result

def fun_sql_cursor_URL_of_Media(id,type):
    if id:
        result = Media.objects.filter(
            to_id= id
        ).filter(
            類別 = type
        )
        
    return result
        

def fun_sql_cursor_MAP_in_SOI(**kwargs):
    sid = kwargs.get('id')
    if sid:
        result = Upload_map.objects.filter(
            SOI_ID = sid
        ).filter(
            描述 = "總圖"
        )
    return result
        
def fun_sql_cursor_REGION_in_SOI(**kwargs):  
    sid = kwargs.get('id')
    floor = kwargs.get('floor')
    if sid:
        result = Upload_map.objects.filter(
            SOI_ID=sid
        ).filter(
            樓層 = floor
        )
    return result
    """
    
    
    
    
    
    
    
    
    
    
    