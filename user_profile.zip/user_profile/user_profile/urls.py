from django.contrib import admin
from django.urls import path
from django.urls import include  # 要導入這個include
from django.conf.urls.static import static
from django.conf import settings
from django.conf.urls import url
from rest_framework.routers import DefaultRouter
from searchDB import views


router = DefaultRouter()
router.register(r'AOI', views.AOIViewSet)
router.register(r'LOI', views.LOIViewSet)
router.register(r'POI', views.POIViewSet)
router.register(r'MAP', views.MAPViewSet)
router.register(r'SOI',views.SOIViewSet)
router.register(r'Media',views.MediaViewSet)
router.register(r'Beacon',views.BeaconViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('upload_profile/', include('upload_profile.urls')),
    url(r'api/', include(router.urls)),
    #url(r'^', include('django.contrib.auth.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)