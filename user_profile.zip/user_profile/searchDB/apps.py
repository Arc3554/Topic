from django.apps import AppConfig


class SearchdbConfig(AppConfig):
    name = 'searchDB'
