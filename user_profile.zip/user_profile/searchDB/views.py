from django.shortcuts import render
from upload_profile.models import *
from searchDB.serializers import *
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.renderers import JSONRenderer
from rest_framework import viewsets

class POIViewSet(viewsets.ModelViewSet):
    queryset = POI.objects.all()
    serializer_class = POISerializer
    
    # /api/POI/getPoi/
    @action(detail=False, methods=['get'])
    def getPoi(self, request):
        if "id" in request.GET and "type" in request.GET:
            type = request.query_params.get('type', None) #SOI| AOI | LOI
            id = request.query_params.get('id', None) #s_id | a_id | l_id
            pois = fcn_sql_query_poi(type=type, id=id)
            return Response(pois, status=status.HTTP_200_OK)
        elif "author" in request.GET:
            author = request.query_params.get('author', None)
            pois = POI.objects.raw('SELECT * FROM [MOE3].[dbo].[proj_POI] WHERE contributor = %s' , [author])
            serializer = POISerializer(pois, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            pois = POI.objects.raw('SELECT * FROM [MOE3].[dbo].[proj_POI]')
            serializer = POISerializer(pois, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)       
    
        
class MAPViewSet(viewsets.ModelViewSet):
    queryset = MAP.objects.all()
    serializer_class = MAPSerializer
    
    # /api/MAP/getMap/
    @action(detail=False, methods=['get'])
    def getMap(self, request):
        type = request.query_params.get('type', None) #SOI| AOI | LOI
        id = request.query_params.get('id', None) #s_id | a_id | l_id
        map = fcn_sql_query_map(type=type, id=id)
        return Response(map, status=status.HTTP_200_OK)
        
    # /api/MAP/getDiffMap/
    @action(detail=False, methods=['get']) 
    def getDiffMap(self, request):
        id = request.query_params.get('id', None) #m_id 
        diffmaps = fcn_sql_query_diffmap(id=id)
        return Response(diffmaps, status=status.HTTP_200_OK)
        
class SOIViewSet(viewsets.ModelViewSet):
    queryset = SOI.objects.all()
    serializer_class = SOISerializer
    
    # /api/SOI/getSoi/
    @action(detail=False, methods=['get'])
    def getSoi(self, request):
        if "author" in request.GET:
            author = request.query_params.get('author', None)
            sois = SOI.objects.raw('SELECT * FROM dbo.proj_SOI WHERE contributor = %s' , [author])
            serializer = SOISerializer(sois, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            sois = fcn_sql_query_soi()
            return Response(sois, status=status.HTTP_200_OK)
        
class AOIViewSet(viewsets.ModelViewSet):
    queryset = AOI.objects.all()
    serializer_class = AOISerializer
    
    # /api/AOI/getAoiInGoogleMap/
    @action(detail=False, methods=['get'])
    def getAoiInGoogleMap(self, request):
        aois = fcn_sql_query_aoi_GoogleMap()
        return Response(aois, status=status.HTTP_200_OK)
    
    # /api/AOI/getAoiInSOI/
    @action(detail=False, methods=['get'])    
    def getAoiInSOI(self, request):
        sid = request.query_params.get('id', None) 
        aois = AOI.objects.raw('SELECT * FROM dbo.proj_AOI WHERE SOI_ID = %s and id=AOI_group', [sid])
        serializer = AOISerializer(aois, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    # /api/AOI/getAoi/
    @action(detail=False, methods=['get'])    
    def getAoi(self, request):
        if "author" in request.GET:
            author = request.query_params.get('author', None)
            aois = AOI.objects.raw('SELECT * FROM dbo.proj_AOI WHERE contributor = %s' , [author])
            serializer = AOISerializer(aois, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
             aois = AOI.objects.raw('SELECT * FROM dbo.proj_AOI ')
             serializer = AOISerializer(aois, many=True)
             return Response(serializer.data, status=status.HTTP_200_OK)
        
    # /api/AOI/getGroupLeader/
    @action(detail=False, methods=['get'])    
    def getGroupLeader(self, request):
        aois = AOI.objects.raw('SELECT * FROM dbo.proj_AOI WHERE id=AOI_group')
        serializer = AOISerializer(aois, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    # /api/AOI/getOtherFloor/
    @action(detail=False, methods=['get'])
    def getOtherFloor(self, request):
        aid = request.query_params.get('id', None)
        aoi = AOI.objects.raw('SELECT * FROM dbo.proj_AOI WHERE id = %s', [aid])
        aois=[]
        if(len(aoi)>0):
            aois = AOI.objects.raw('SELECT * FROM dbo.proj_AOI WHERE AOI_group = %s ORDER BY floor', [aoi[0].AOI_group])
        serializer = AOISerializer(aois, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
class LOIViewSet(viewsets.ModelViewSet):
    queryset = LOI.objects.all()
    serializer_class = LOISerializer
    
    # /api/LOI/getLoiInGoogleMap/
    @action(detail=False, methods=['get'])
    def getLoiInGoogleMap(self, request):
        aois = fcn_sql_query_loi_GoogleMap()
        return Response(aois, status=status.HTTP_200_OK)
        
    # /api/LOI/getLoiInSOI/
    @action(detail=False, methods=['get'])    
    def getLoiInSOI(self, request):
        sid = request.query_params.get('id', None) 
        lois = LOI.objects.raw('SELECT * FROM dbo.proj_LOI WHERE SOI_ID = %s and id=LOI_group', [sid])
        serializer = LOISerializer(lois, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    # /api/LOI/getLoi/
    @action(detail=False, methods=['get'])    
    def getLoi(self, request):
        if "author" in request.GET:
            author = request.query_params.get('author', None)
            lois = LOI.objects.raw('SELECT * FROM dbo.proj_LOI WHERE contributor = %s' , [author])
            serializer = LOISerializer(lois, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            lois = AOI.objects.raw('SELECT * FROM dbo.proj_LOI ')
            serializer = LOISerializer(lois, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        
    # /api/LOI/getGroupLeader/
    @action(detail=False, methods=['get'])    
    def getGroupLeader(self, request):
        lois = LOI.objects.raw('SELECT * FROM dbo.proj_LOI WHERE id=LOI_group')
        serializer = LOISerializer(lois, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    # /api/LOI/getOtherFloor/
    @action(detail=False, methods=['get'])
    def getOtherFloor(self, request):
        lid = request.query_params.get('id', None)
        loi = LOI.objects.raw('SELECT * FROM dbo.proj_LOI WHERE id = %s', [lid])
        lois=[]
        if(len(loi)>0):
            lois = LOI.objects.raw('SELECT * FROM dbo.proj_LOI WHERE LOI_group = %s ORDER BY floor', [loi[0].LOI_group])
        serializer = LOISerializer(lois, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
class MediaViewSet(viewsets.ModelViewSet):
    queryset = Media.objects.all()
    serializer_class = MediaSerializer
    
    #/api/Media/getPoiMedia/?id=
    @action(detail=False, methods=['get'])
    def getPoiMedia(self, request):
        if "id" in request.GET:
            pid = request.query_params.get('id', None)
            media = Media.objects.raw("SELECT * FROM [MOE3].[dbo].[proj_Media] WHERE (TYPE = 'video' or TYPE = 'image' or TYPE = 'sound' or TYPE = 'audio') and to_id = %s", [pid])
            serializer =  MediaSerializer(media, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK) 
        
class BeaconViewSet(viewsets.ModelViewSet):
    queryset = Beacon.objects.all()
    serializer_class = MediaSerializer
    
    #/api/Beacon/getBeacon/?id=
    @action(detail=False, methods=['get'])
    def getBeacon(self, request):
        if "id" in request.GET:
            mid = request.query_params.get('id', None)
            beacons = Beacon.objects.raw("SELECT * FROM [MOE3].[dbo].[proj_Beacon] WHERE MAP_ID =  %s", [mid])
            serializer =  BeaconSerializer(beacons, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK) 
        
    """
    # /api/POI/getPOIinAOI/
    @action(detail=False, methods=['get'])
    def getPOIinAOI(self, request):
        id = request.query_params.get('id', None) #aoi_id
        if id:
            poi = fun_sql_cursor_POI_in_AOI(id=id)
            return Response(poi, status=status.HTTP_200_OK)
    """

"""

# Create your views here.
class AOILOISummaryViewSet(viewsets.ModelViewSet):
    queryset = AOILOI_summary.objects.all()
    serializer_class = AOILOISummarySerializer
    
    # /api/AOI/getAoi/
    @action(detail=False, methods=['get'])
    def getAoi(self, request):
        id = request.query_params.get('id', None) #map_id
        aois = fun_raw_sql_query_aoi_summary(id=id)
        serializer = AOILOISummarySerializer(aois, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
   
# /api/SOI   
class SOIViewSet(viewsets.ModelViewSet):
    queryset = Make_poi.objects.all()
    serializer_class = SOISerializer
    
    # /api/SOI/getMAPinSOI/?id=
    @action(detail=False, methods=['get'])
    def getMAPinSOI(self, request):
        if "id" in request.GET:
            id = request.query_params.get('id', None)
            maps = fun_sql_cursor_MAP_in_SOI(id=id)
            serializer =  SOIMAPSerializer(maps,many=True)
            result = serializer.data
            mid = result[0]['id']
            urls = fun_sql_cursor_URL_of_Media(id=mid,type='MAP')
            serializer_2 =  MediaSerializer(urls, many=True)
            print(serializer_2.data)
            murl = serializer_2.data[0]['url']
            result.append({'url': murl},)
        return Response( result, status=status.HTTP_200_OK) 
    
    # /api/SOI/getREGIONinSOI/?id= &floor=
    @action(detail=False, methods=['get'])
    def getREGIONinSOI(self, request):
        if "id" in request.GET and "floor" in request.GET:
            id = request.query_params.get('id', None)
            floor = request.query_params.get('floor', None)
            print(floor)
            regions = fun_sql_cursor_REGION_in_SOI(id=id,floor=floor)
            serializer =SOIMAPSerializer(regions, many=True)
            
        return Response(serializer.data, status=status.HTTP_200_OK)
"""