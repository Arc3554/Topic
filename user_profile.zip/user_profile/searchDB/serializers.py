from rest_framework import serializers
from upload_profile.models import *

class POISerializer(serializers.ModelSerializer):
    class Meta:
        model = POI
        fields = '__all__'
        #fields = ('id', 'song', 'singer', 'last_modify_date', 'created')
        
class MAPSerializer(serializers.ModelSerializer):
    class Meta:
        model = MAP
        fields = '__all__'
        
class SOISerializer(serializers.ModelSerializer):
    class Meta:
        model = SOI
        fields = '__all__'
        
class AOISerializer(serializers.ModelSerializer):
    class Meta:
        model = AOI
        fields = '__all__'
        
class LOISerializer(serializers.ModelSerializer):
    class Meta:
        model = LOI
        fields = '__all__'
        
class MediaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Media
        fields = '__all__'
        
class BeaconSerializer(serializers.ModelSerializer):
    class Meta:
        model = Beacon
        fields = '__all__'

"""
        
class SOIMAPSerializer(serializers.ModelSerializer):
    class Meta:
        model = Upload_map
        fields = '__all__'
        """